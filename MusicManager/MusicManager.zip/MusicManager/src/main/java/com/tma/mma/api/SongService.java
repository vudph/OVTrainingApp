package com.tma.mma.api;

import java.io.File;
import java.util.List;

public interface SongService {
	public static final String BEAN_ID = "songService";
    public static final String DEFAULT_SONG_LOCATION = "musics".concat(File.separator);

    public void addSong(SongVO song);

    public void deleteSong(SongVO song);

    public void deleteSongs(List<SongVO> songs);

    public void deleteSong(Long id);

    public List<SongVO> getAllSongs();

    public void updateSong(SongVO song);

    public List<SongVO> getSongs(Paging paging);

    public List<SongVO> getSongs(Paging paging, List<Ordering> orders);

    public SongVO getSong(Long id);
}

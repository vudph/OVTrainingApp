package com.tma.mma.api;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SongVO {

    private Long m_id;

    private String m_name;

    private String m_path;

    private String m_genre;

    private Date m_lastUpdate;

    @XmlElement
    public String getPath() {
        return m_path;
    }

    public void setPath(String path) {
        this.m_path = path;
    }


    @XmlElement
    public Long getId() {
        return m_id;
    }

    public void setId(Long id) {
        this.m_id = id;
    }

    @XmlElement
    public String getName() {
        return m_name;
    }

    public void setName(String name) {
        this.m_name = name;
    }

    @XmlElement
    public String getGenre() {
        return m_genre;
    }

    public void setGenre(String genre) {
        this.m_genre = genre;
    }

    @XmlElement
    public Date getLastUpdate() {
        return m_lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.m_lastUpdate = lastUpdate;
    }
}

package com.tma.mma.app;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.tma.mma.api.Ordering;
import com.tma.mma.api.Paging;
import com.tma.mma.api.SongService;
import com.tma.mma.api.SongVO;
import com.tma.mma.app.utils.MusicUtil;
import com.tma.mma.app.utils.SongDataConversion;
import com.tma.mma.dao.GenericDao;
import com.tma.mma.dao.GenericHibernateDao;
import com.tma.mma.model.Song;

public class SongServiceImpl implements SongService {

    private TransactionTemplate m_txTemplate;
    private GenericDao<Song, Long> m_songDao;

    public SongServiceImpl(SessionFactory sessionFactory, TransactionTemplate txTemplate) {
        m_txTemplate = txTemplate;
        m_songDao = new GenericHibernateDao<Song, Long>(sessionFactory){};
    }
    
    public SongServiceImpl(GenericDao<Song, Long> dao, TransactionTemplate txTemplate) {
        m_txTemplate = txTemplate;
        m_songDao = dao;
    }

    @Override
    public void addSong(final SongVO song) {
        m_txTemplate.execute(new TransactionCallback<Void>() {
            @Override
            public Void doInTransaction(TransactionStatus arg0) {
                m_songDao.makePersistence(SongDataConversion.convertToEntity(song));
                return null;
            }
        });
    }

    @Override
    public void deleteSong(final SongVO song) {
        m_txTemplate.execute(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(TransactionStatus arg0) {
                m_songDao.makeTransient(SongDataConversion.convertToEntity(song));
                return null;
            }
        });
    }

    @Override
    public List<SongVO> getAllSongs() {

        return m_txTemplate.execute(new TransactionCallback<List<SongVO>>() {
            @Override
            public List<SongVO> doInTransaction(TransactionStatus arg0) {
                return SongDataConversion.convertToVOs(m_songDao.findAll());
            }
        });
    }

    @Override
    public void updateSong(final SongVO song) {
        // set the last update
        // song.setLastUpdate(Calendar.getInstance().)
        m_txTemplate.execute(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(TransactionStatus arg0) {
                m_songDao.makePersistence(SongDataConversion.convertToEntity(song));
                return null;
            }
        });
    }

    @Override
    public List<SongVO> getSongs(final Paging paging) {
        return m_txTemplate.execute(new TransactionCallback<List<SongVO>>() {

            @Override
            public List<SongVO> doInTransaction(TransactionStatus arg0) {
                return SongDataConversion.convertToVOs(m_songDao.findWithPaging(paging));
            }
        });
    }

    @Override
    public void deleteSong(final Long id) {
        m_txTemplate.execute(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(TransactionStatus arg0) {
                Song song = m_songDao.findById(id);
                
                if (song != null) {
                    m_songDao.makeTransient(song);
                }
                return null;
            }
        });
    }

    @Override
    public List<SongVO> getSongs(final Paging paging, final List<Ordering> orders) {
        return m_txTemplate.execute(new TransactionCallback<List<SongVO>>() {
            @Override
            public List<SongVO> doInTransaction(TransactionStatus arg0) {
                return SongDataConversion.convertToVOs(m_songDao.findWithPagingAndOrders(paging, orders));
            }
        });
    }

    @Override
    public SongVO getSong(final Long id) {
        return m_txTemplate.execute(new TransactionCallback<SongVO>() {
            @Override
            public SongVO doInTransaction(TransactionStatus arg0) {
                Song song = m_songDao.findById(id);
                if (song != null) {
                    return SongDataConversion.convertToVO(song);
                }
                return null;
            }
        });
    }

    @Override
    public void deleteSongs(final List<SongVO> songs) {
        m_txTemplate.execute(new TransactionCallback<Void>() {

            @Override
            public Void doInTransaction(TransactionStatus arg0) {
                m_songDao.makeTransient(SongDataConversion.convertToEntities(songs));
                return null;
            }
        });
    }
}

package com.tma.mma.app.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.tma.mma.api.SongService;

public class MusicUtil {

    private static final Logger LOGGER = Logger.getLogger(MusicUtil.class);

    public static String buildSongPath(String rootDir, String songName) {
        String dirPath = rootDir.concat(File.separator).concat(SongService.DEFAULT_SONG_LOCATION);
        if (!createDir(dirPath)) {
            LOGGER.warn("Can not create " + SongService.DEFAULT_SONG_LOCATION);
        }
        return dirPath.concat(songName);
    }

    public static void deleteFile(String filePath) {
        if (filePath == null) {
            return;
        }
        File file = new File(filePath);
        try {
            file.delete();
        } catch (Exception e) {
            LOGGER.error("The file " + filePath + " can not be deleted!");
        }
    }

    // save to somewhere
    public static void writeFile(byte[] content, String filename) {

        FileOutputStream fop = null;
        File file = new File(filename);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }

            fop = new FileOutputStream(file);

            IOUtils.write(content, fop);
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        } finally {
            IOUtils.closeQuietly(fop);
        }
    }

    public static String getFileName(MultivaluedMap<String, String> header) {
        String[] contentDisposition = header.getFirst("Content-Disposition").split(";");
        LOGGER.info("contentDisposition:" + contentDisposition);
        for (String filename : contentDisposition) {
            if ((filename.trim().startsWith("filename"))) {

                String[] name = filename.split("=");

                String finalFileName = name[1].trim().replaceAll("\"", "");
                return finalFileName;
            }
        }
        return "unknown";
    }

    private static boolean createDir(String path) {
        File dir = new File(path);
        if (!dir.exists()) {
            return dir.mkdirs();
        }
        return true;
    }
}

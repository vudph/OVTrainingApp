package com.tma.mma.app.utils;

import java.util.ArrayList;
import java.util.List;

import com.tma.mma.api.SongVO;
import com.tma.mma.model.Song;

public class SongDataConversion {

    public static List<SongVO> convertToVOs(List<Song> songs) {
        List<SongVO> result = new ArrayList<SongVO>();
        for (Song song : songs) {
            result.add(convertToVO(song));
        }
        return result;
    }

    public static SongVO convertToVO(Song song) {
        if (song != null) {
            SongVO vo = new SongVO();
            vo.setId(song.getId());
            vo.setGenre(song.getGenre());
            vo.setLastUpdate(song.getLastUpdate());
            vo.setName(song.getName());

            vo.setPath(song.getPath());
            return vo;
        } else {
            return null;
        }
    }

    public static List<Song> convertToEntities(List<SongVO> songs) {
        List<Song> rs = new ArrayList<Song>();
        for (SongVO vo : songs) {
            rs.add(convertToEntity(vo));
        }
        return rs;
    }

    public static Song convertToEntity(SongVO vo) {
        Song song = new Song();

        song.setId(vo.getId());
        song.setName(vo.getName());
        if (vo.getPath() != null) {
            song.setPath(vo.getPath());
        }
        song.setGenre(vo.getGenre());
        return song;
    }
}

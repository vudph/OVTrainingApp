package com.tma.mma.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import com.tma.mma.api.Ordering;
import com.tma.mma.api.Paging;

public interface GenericDao<T extends Serializable, ID extends Serializable> {

    public T findById(ID id);

    public List<T> findAll();

    public List<T> findWithPaging(Paging paging);

    public List<T> findWithPagingAndOrders(Paging paging, List<Ordering> orders);

    public T makePersistence(T entity);

    public void makePersistence(Collection<T> entities);

    public T makeTransient(T entity);

    public void makeTransient(Collection<T> entities);

    public T findByAttribute(String attributeName, Object value);
}

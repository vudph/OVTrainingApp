package com.tma.mma.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.Collection;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import com.tma.mma.api.Ordering;
import com.tma.mma.api.Paging;

public class GenericHibernateDao<T extends Serializable, ID extends Serializable> implements GenericDao<T, ID> {

    private SessionFactory m_sessionFactory;
    private Class<T> m_persistentClass;

    @SuppressWarnings("unchecked")
    public GenericHibernateDao(SessionFactory sessionFactory) {
        this.m_sessionFactory = sessionFactory;
        this.m_persistentClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    public Session getCurrentSession() {
        return m_sessionFactory.getCurrentSession();
    }

    public Class<T> getPersistentClass() {
        return m_persistentClass;
    }

    @SuppressWarnings("unchecked")
    @Override
    public T findById(ID id) {
        return (T) getCurrentSession().load(getPersistentClass(), id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findAll() {
        return createCriteria().list();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findWithPaging(Paging paging) {
        Criteria criteria = createCriteria();
        criteria.setFirstResult(paging.getStartIndex());
        criteria.setMaxResults(paging.getNumberOfRecords());
        return criteria.list();
    }

    @Override
    public T makePersistence(T entity) {
        getCurrentSession().saveOrUpdate(entity);
        return entity;
    }

    @Override
    public void makePersistence(Collection<T> entities) {
        Session session = getCurrentSession();
        for (T entity : entities) {
            session.saveOrUpdate(entity);
        }
    }

    @Override
    public T makeTransient(T entity) {
        getCurrentSession().delete(entity);
        return entity;
    }

    @Override
    public void makeTransient(Collection<T> entities) {

        Session session = getCurrentSession();
        for (T entity : entities) {
            session.delete(entity);
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public T findByAttribute(String attributeName, Object value) {
        return (T) createCriteria().add(Restrictions.eq(attributeName, value)).uniqueResult();
    }

    protected Criteria createCriteria() {
        Criteria criteria = getCurrentSession().createCriteria(getPersistentClass());
        criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        return criteria;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> findWithPagingAndOrders(Paging paging, List<Ordering> orders) {
        Criteria criteria = createCriteria();
        criteria.setFirstResult(paging.getStartIndex());
        criteria.setMaxResults(paging.getNumberOfRecords());
        for (Ordering order : orders) {
            if (Ordering.DESC.equals(order.getMode())) {
                criteria.addOrder(Order.desc(order.getAttribute()));
            } else if (Ordering.ASC.equals(order.getMode())) {
                criteria.addOrder(Order.asc(order.getAttribute()));
            }
        }
        return criteria.list();
    }

}

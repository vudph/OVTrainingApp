package com.tma.mma.resourceprovider;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.media.sse.SseFeature;
import org.glassfish.jersey.server.ResourceConfig;

@ApplicationPath("resources")
public class Resources extends ResourceConfig {
    public Resources() {
        packages(SongResource.class.getPackage().getName());

        register(SseFeature.class);
        register(MultiPartFeature.class);
        register(JacksonFeature.class);
    }
}

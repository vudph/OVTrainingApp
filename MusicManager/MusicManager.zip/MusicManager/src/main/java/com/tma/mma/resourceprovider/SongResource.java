package com.tma.mma.resourceprovider;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.io.IOUtils;
import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataMultiPart;
import org.glassfish.jersey.media.sse.EventOutput;
import org.glassfish.jersey.media.sse.OutboundEvent;
import org.glassfish.jersey.media.sse.SseBroadcaster;
import org.glassfish.jersey.media.sse.SseFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.tma.mma.api.Ordering;
import com.tma.mma.api.Paging;
import com.tma.mma.api.SongService;
import com.tma.mma.api.SongVO;
import com.tma.mma.app.utils.MusicUtil;
import com.tma.mma.springcontext.MMAApplicationContext;

@Path("/song")
public class SongResource {

    private static final Logger LOGGER = LoggerFactory.getLogger(SongResource.class);

    private static final SseBroadcaster BROADCASTER = new SseBroadcaster();

    private SongService m_songService;

    private String m_contextDir;

    public SongResource() {
        m_songService = MMAApplicationContext.getService(SongService.class, SongService.BEAN_ID);
    }

    private void loadContextPath() {
        if (m_contextDir == null) {
            HttpServletRequest httpServletRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                    .getRequest();
            m_contextDir = httpServletRequest.getSession().getServletContext().getRealPath("/");
        }
    }

    /**
     * Save song file
     * 
     * @param input
     * @return
     */
    @POST
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response saveSong(FormDataMultiPart input) {
        loadContextPath();
        String fileName = "";
        String filePath = "";
        Map<String, List<FormDataBodyPart>> uploadForm = input.getFields();
        List<FormDataBodyPart> inputParts = uploadForm.get("uploadedFile");

        String songName = uploadForm.get("name").get(0).getValue();
        String songGenre = uploadForm.get("genre").get(0).getValue();
        for (FormDataBodyPart inputPart : inputParts) {
            InputStream inputStream = null;
            try {

                MultivaluedMap<String, String> header = inputPart.getHeaders();
                fileName = MusicUtil.getFileName(header);
                LOGGER.info("File Name: %s", fileName);
                // convert the uploaded file to inputstream
                inputStream = inputPart.getEntityAs(InputStream.class);

                byte[] bytes = IOUtils.toByteArray(inputStream);

                // constructs upload file path
                filePath = MusicUtil.buildSongPath(m_contextDir, fileName);
                LOGGER.info("File Path: %s", filePath);
                MusicUtil.writeFile(bytes, filePath);

                LOGGER.info("Saving file done");

            } catch (IOException e) {
                LOGGER.error(e.getMessage(), e);
            } finally {
                IOUtils.closeQuietly(inputStream);
            }
        }

        SongVO songVO = new SongVO();
        songVO.setName(songName);
        songVO.setGenre(songGenre);
        filePath = SongService.DEFAULT_SONG_LOCATION.concat(fileName);
        songVO.setPath(filePath);
        songVO.setLastUpdate(new Date());
        songVO.setLastUpdate(Calendar.getInstance().getTime());
        m_songService.addSong(songVO);

        // Broadcasting a song event with the name of the newly added item in data
        BROADCASTER.broadcast(new OutboundEvent.Builder().name("song").data(String.class, "add song " + songVO.getName()).build());

        return Response.status(Status.OK).entity("ok").build();
    }

    /**
     * Update song's profile
     * 
     * @param song
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateSong(SongVO song) {
        song.setLastUpdate(Calendar.getInstance().getTime());
        if (song.getId() != null) {
            m_songService.updateSong(song);
        } else {
            m_songService.addSong(song);
        }

        // Broadcasting a song event with the name of the newly added item in data
        BROADCASTER.broadcast(new OutboundEvent.Builder().name("song").data(String.class, "update song " + song.getName()).build());
    }

    /**
     * Delete song's profile
     * 
     * @param id
     */
    @DELETE
    @Path("{id}")
    public void deleteSong(@PathParam("id") Long id) {
    	SongVO vo = m_songService.getSong(id);
    	File tmpFile = new File(vo.getPath());
    	loadContextPath();
    	String realPath = MusicUtil.buildSongPath(m_contextDir, tmpFile.getName());
    	MusicUtil.deleteFile(realPath);
        m_songService.deleteSong(id);

        // Broadcasting a song event with the name of the newly added item in data
        BROADCASTER.broadcast(new OutboundEvent.Builder().name("song").data(String.class, "delete song id " + id).build());
    }

    /**
     * Get song's profile
     * 
     * @param id
     * @return
     */
    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public SongVO getSong(@PathParam("id") Long id) {
        return m_songService.getSong(id);
    }

    /**
     * Event service
     * 
     * @return
     */
    @GET
    @Path("events")
    @Produces(SseFeature.SERVER_SENT_EVENTS)
    public EventOutput itemEvents() {
        final EventOutput eventOutput = new EventOutput();
        BROADCASTER.add(eventOutput);
        return eventOutput;
    }

    /**
     * Get song's profiles
     * 
     * @param startIndex
     * @param maxRecords
     * @param orderDesc
     * @param orderAsc
     * @return
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<SongVO> getSongs(@QueryParam("start") Integer startIndex, @QueryParam("max") Integer maxRecords,
            @QueryParam("orderDesc") List<String> orderDesc, @QueryParam("orderAsc") List<String> orderAsc) {
        Paging paging = new Paging();
        paging.setNumberOfRecords(maxRecords);
        paging.setStartIndex(startIndex);

        List<Ordering> orders = new ArrayList<Ordering>();
        if (orderDesc != null) {
            for (String attribute : orderDesc) {
                Ordering order = new Ordering();
                order.setAttribute(attribute);
                order.setMode(Ordering.DESC);
                orders.add(order);
            }
        }
        if (orderAsc != null) {
            for (String attribute : orderAsc) {
                Ordering order = new Ordering();
                order.setAttribute(attribute);
                order.setMode(Ordering.ASC);
                orders.add(order);
            }
        }

        return m_songService.getSongs(paging, orders);
    }
}

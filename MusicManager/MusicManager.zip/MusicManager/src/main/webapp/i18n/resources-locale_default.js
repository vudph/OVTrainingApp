[
    {
        "key":"_HomeTitle_",
        "value":"Music Manager",
        "description":"Home page title text"
    },
    {
        "key":"_Lang_",
        "value":"Language",
        "description":"Language title"
    },
    {
        "key":"_Add_",
        "value":"Add",
        "description":"Add button"
    },
    {
        "key":"_Delete_",
        "value":"Delete",
        "description":"Delete button"
    },
    {
        "key":"_Total_",
        "value":"Total items",
        "description":"Total items"
    },
    {
        "key":"_Selected_",
        "value":"Selected items",
        "description":"Selected items"
    },
    {
        "key":"_Search_",
        "value":"Search",
        "description":"Search"
    },
    {
        "key":"_AddSong_",
        "value":"Add Song",
        "description":"Add Song"
    },
    {
        "key":"_Name_",
        "value":"Name",
        "description":"Name"
    },
    {
        "key":"_Genre_",
        "value":"Genre",
        "description":"Genre"
    },
    {
        "key":"_File_",
        "value":"File",
        "description":"File"
    },
    {
        "key":"_Add_Btn",
        "value":"Add",
        "description":"Add"
    },
    {
        "key":"_Song_",
        "value":"Song",
        "description":"Song"
    },
    {
        "key":"_Save_Btn",
        "value":"Save",
        "description":"Save"
    },
    {
        "key":"_Edit_Btn",
        "value":"Edit",
        "description":"Edit"
    },
    {
        "key":"_Delete_Btn",
        "value":"Delete",
        "description":"Delete"
    }
]
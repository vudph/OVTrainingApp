[
    {
        "key":"_HomeTitle_",
        "value":"Quản lý nhạc",
        "description":"Home page title text"
    },
    {
        "key":"_Lang_",
        "value":"Ngôn ngữ",
        "description":"Language title"
    },
    {
        "key":"_Add_",
        "value":"Thêm nhạc",
        "description":"Add button"
    },
    {
        "key":"_Delete_",
        "value":"Xóa nhạc",
        "description":"Delete button"
    },
    {
        "key":"_Total_",
        "value":"Tổng số",
        "description":"Total items"
    },
    {
        "key":"_Selected_",
        "value":"Đã chọn",
        "description":"Selected items"
    },
    {
        "key":"_Search_",
        "value":"Tìm kiếm",
        "description":"Search"
    },
    {
        "key":"_AddSong_",
        "value":"Thêm Nhạc",
        "description":"Add Song"
    },
    {
        "key":"_Name_",
        "value":"Tên bài hát",
        "description":"Name"
    },
    {
        "key":"_Genre_",
        "value":"Thể loại",
        "description":"Genre"
    },
    {
        "key":"_File_",
        "value":"Tập tin",
        "description":"File"
    },
    {
        "key":"_Add_Btn",
        "value":"Thêm",
        "description":"Add"
    },
    {
        "key":"_Song_",
        "value":"Nhạc",
        "description":"Song"
    },
    {
        "key":"_Save_Btn",
        "value":"Lưu",
        "description":"Save"
    },
    {
        "key":"_Edit_Btn",
        "value":"Sửa",
        "description":"Edit"
    },
    {
        "key":"_Delete_Btn",
        "value":"Xóa",
        "description":"Delete"
    }
]
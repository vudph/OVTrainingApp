package com.tma.mma.app;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.tma.mma.api.SongService;
import com.tma.mma.api.SongVO;
import com.tma.mma.dao.GenericDao;
import com.tma.mma.model.Song;

public class SongServiceImplTest {
    private SongService m_songService;
    private GenericDao<Song, Long> m_dao;
    private TransactionTemplate m_txTemplate;
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Before
    public void setUp() {
        m_dao = mock(GenericDao.class);
        m_txTemplate = mock(TransactionTemplate.class);
        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                TransactionCallback txc = (TransactionCallback) invocation.getArguments()[0];
               return txc.doInTransaction(null);
            }
        }).when(m_txTemplate).execute((TransactionCallback) anyObject());
        m_songService = new SongServiceImpl(m_dao, m_txTemplate);
    }

    @SuppressWarnings("rawtypes")
    @Test
    public void testAddSong() {
        final Song[] songAdded = new Song[1];
        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                songAdded[0] = (Song) invocation.getArguments()[0];
                return null;
            }
        }).when(m_dao).makePersistence((Song) anyObject());
        
        SongVO s = new SongVO();
        s.setName("The day you went away");
        s.setGenre("pop");
        m_songService.addSong(s);
        assertEquals("The day you went away", songAdded[0].getName());
        assertEquals("pop", songAdded[0].getGenre());
    }
    
    @SuppressWarnings("rawtypes")
    @Test
    public void testDeleteSong() {
        final Song[] songAdded = new Song[1];
        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                songAdded[0] = (Song) invocation.getArguments()[0];
                return null;
            }
        }).when(m_dao).makeTransient((Song) anyObject());
        SongVO s = new SongVO();
        s.setName("The day you went away");
        s.setGenre("pop");
        m_songService.deleteSong(s);
        assertEquals("The day you went away", songAdded[0].getName());
        assertEquals("pop", songAdded[0].getGenre());
    }
    
    @Test
    public void testGetAllSongs() {
        List<Song> songs = new ArrayList<Song>();
        Song s = new Song();
        s.setName("Song 1");
        s.setPath("/mma/songs/song1.mp3");
        songs.add(s);
        when(m_dao.findAll()).thenReturn(songs);
        List<SongVO> result = m_songService.getAllSongs();
        assertEquals(1, result.size());
        assertEquals("Song 1", result.get(0).getName());
        assertEquals("/mma/songs/song1.mp3", result.get(0).getPath());
    }
    
    @SuppressWarnings("rawtypes")
    @Test
    public void testUpdateSong() {
        final Song[] songAdded = new Song[1];
        doAnswer(new Answer() {
            @Override
            public Object answer(InvocationOnMock invocation) throws Throwable {
                songAdded[0] = (Song) invocation.getArguments()[0];
                return null;
            }
        }).when(m_dao).makePersistence((Song) anyObject());
        SongVO s = new SongVO();
        s.setName("The day you went away");
        s.setGenre("pop");
        m_songService.updateSong(s);
        assertEquals("The day you went away", songAdded[0].getName());
        assertEquals("pop", songAdded[0].getGenre());
    }
}

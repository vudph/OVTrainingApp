-- MySQL dump 10.11
--
-- Host: localhost    Database: nmsdb
-- ------------------------------------------------------
-- Server version	5.0.96-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Alarm`
--

DROP TABLE IF EXISTS `Alarm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Alarm` (
  `id` bigint(20) NOT NULL auto_increment,
  `severity` int(11) default NULL,
  `srcAlarm_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK3C68A313118DD22` (`srcAlarm_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Alarm`
--

LOCK TABLES `Alarm` WRITE;
/*!40000 ALTER TABLE `Alarm` DISABLE KEYS */;
INSERT INTO `Alarm` VALUES (1,1,2),(2,1,3),(3,1,5),(4,1,6),(5,1,8),(6,1,9),(7,1,11),(8,1,12),(9,2,2),(11,2,5),(12,2,6),(13,2,8),(14,2,9),(15,2,11),(16,2,12),(17,0,5),(18,0,6),(19,0,5);
/*!40000 ALTER TABLE `Alarm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Attribute`
--

DROP TABLE IF EXISTS `Attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Attribute` (
  `id` bigint(20) NOT NULL auto_increment,
  `dataType` varchar(255) default NULL,
  `defaultValue` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `readable` bit(1) default NULL,
  `regex` varchar(255) default NULL,
  `value` varchar(255) default NULL,
  `writable` bit(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Attribute`
--

LOCK TABLES `Attribute` WRITE;
/*!40000 ALTER TABLE `Attribute` DISABLE KEYS */;
INSERT INTO `Attribute` VALUES (1,'java.lang.String',NULL,'Name','',NULL,'Switch 1','\0'),(2,'java.lang.String',NULL,'Status','',NULL,'ACTIVE','\0'),(3,'java.lang.String',NULL,'IP Address','',NULL,'127.0.0.1','\0'),(4,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(5,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(6,'java.lang.String',NULL,'Name','',NULL,'Port 1','\0'),(7,'java.lang.String',NULL,'Status','',NULL,'ACTIVE','\0'),(8,'java.lang.String',NULL,'IP Address','',NULL,'127.0.0.2','\0'),(9,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(10,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(11,'java.lang.String',NULL,'Name','',NULL,'Port 2','\0'),(12,'java.lang.String',NULL,'Status','',NULL,'OFFLINE','\0'),(13,'java.lang.String',NULL,'IP Address','',NULL,'127.0.0.3','\0'),(14,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(15,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(16,'java.lang.String',NULL,'Name','',NULL,'Switch 2','\0'),(17,'java.lang.String',NULL,'Status','',NULL,'ACTIVE','\0'),(18,'java.lang.String',NULL,'IP Address','',NULL,'127.0.10.1','\0'),(19,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(20,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(21,'java.lang.String',NULL,'Name','',NULL,'Port 1','\0'),(22,'java.lang.String',NULL,'Status','',NULL,'ACTIVE','\0'),(23,'java.lang.String',NULL,'IP Address','',NULL,'127.0.10.2','\0'),(24,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(25,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(26,'java.lang.String',NULL,'Name','',NULL,'Port 2','\0'),(27,'java.lang.String',NULL,'Status','',NULL,'OFFLINE','\0'),(28,'java.lang.String',NULL,'IP Address','',NULL,'127.0.10.3','\0'),(29,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(30,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(31,'java.lang.String',NULL,'Name','',NULL,'Router 1','\0'),(32,'java.lang.String',NULL,'Status','',NULL,'ACTIVE','\0'),(33,'java.lang.String',NULL,'IP Address','',NULL,'127.0.1.1','\0'),(34,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(35,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(36,'java.lang.String',NULL,'Name','',NULL,'Port 1','\0'),(37,'java.lang.String',NULL,'Status','',NULL,'ACTIVE','\0'),(38,'java.lang.String',NULL,'IP Address','',NULL,'127.0.1.2','\0'),(39,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(40,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(41,'java.lang.String',NULL,'Name','',NULL,'Port 2','\0'),(42,'java.lang.String',NULL,'Status','',NULL,'OFFLINE','\0'),(43,'java.lang.String',NULL,'IP Address','',NULL,'127.0.1.3','\0'),(44,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(45,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(46,'java.lang.Enum',NULL,'Enum Example','',NULL,'Enum1',''),(47,'java.lang.String',NULL,'Name','',NULL,'Router 2','\0'),(48,'java.lang.String',NULL,'Status','',NULL,'ACTIVE','\0'),(49,'java.lang.String',NULL,'IP Address','',NULL,'127.0.11.1','\0'),(50,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(51,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(52,'java.lang.String',NULL,'Name','',NULL,'Port 1','\0'),(53,'java.lang.String',NULL,'Status','',NULL,'ACTIVE','\0'),(54,'java.lang.String',NULL,'IP Address','',NULL,'127.0.11.2','\0'),(55,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(56,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(57,'java.lang.String',NULL,'Name','',NULL,'Port 2','\0'),(58,'java.lang.String',NULL,'Status','',NULL,'OFFLINE','\0'),(59,'java.lang.String',NULL,'IP Address','',NULL,'127.0.11.3','\0'),(60,'java.lang.String',NULL,'Read Only Example','',NULL,'readOnlyValue','\0'),(61,'java.lang.String',NULL,'Writable Example','',NULL,NULL,''),(62,'java.lang.Enum',NULL,'Enum Example','',NULL,'Enum1','');
/*!40000 ALTER TABLE `Attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AttributeGroup`
--

DROP TABLE IF EXISTS `AttributeGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AttributeGroup` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AttributeGroup`
--

LOCK TABLES `AttributeGroup` WRITE;
/*!40000 ALTER TABLE `AttributeGroup` DISABLE KEYS */;
INSERT INTO `AttributeGroup` VALUES (1,'Generic Config'),(2,'Specific Config'),(3,'Generic Config'),(4,'Specific Config'),(5,'Generic Config'),(6,'Specific Config'),(7,'Generic Config'),(8,'Specific Config'),(9,'Generic Config'),(10,'Specific Config'),(11,'Generic Config'),(12,'Specific Config'),(13,'Generic Config'),(14,'Specific Config'),(15,'Generic Config'),(16,'Specific Config'),(17,'Generic Config'),(18,'Specific Config'),(19,'Generic Config'),(20,'Specific Config'),(21,'Generic Config'),(22,'Specific Config'),(23,'Generic Config'),(24,'Specific Config');
/*!40000 ALTER TABLE `AttributeGroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AttributeGroup_Attribute`
--

DROP TABLE IF EXISTS `AttributeGroup_Attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AttributeGroup_Attribute` (
  `AttributeGroup_id` bigint(20) NOT NULL,
  `attributes_id` bigint(20) NOT NULL,
  UNIQUE KEY `attributes_id` (`attributes_id`),
  KEY `FKFD880EA0AC62869B` (`AttributeGroup_id`),
  KEY `FKFD880EA03BB7931E` (`attributes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AttributeGroup_Attribute`
--

LOCK TABLES `AttributeGroup_Attribute` WRITE;
/*!40000 ALTER TABLE `AttributeGroup_Attribute` DISABLE KEYS */;
INSERT INTO `AttributeGroup_Attribute` VALUES (1,1),(1,2),(1,3),(2,4),(2,5),(3,6),(3,7),(3,8),(4,9),(4,10),(5,11),(5,12),(5,13),(6,14),(6,15),(7,16),(7,17),(7,18),(8,19),(8,20),(9,21),(9,22),(9,23),(10,24),(10,25),(11,26),(11,27),(11,28),(12,29),(12,30),(13,31),(13,32),(13,33),(14,34),(14,35),(15,36),(15,37),(15,38),(16,39),(16,40),(17,41),(17,42),(17,43),(18,44),(18,45),(18,46),(19,47),(19,48),(19,49),(20,50),(20,51),(21,52),(21,53),(21,54),(22,55),(22,56),(23,57),(23,58),(23,59),(24,60),(24,61),(24,62);
/*!40000 ALTER TABLE `AttributeGroup_Attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Attribute_validValues`
--

DROP TABLE IF EXISTS `Attribute_validValues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Attribute_validValues` (
  `Attribute_id` bigint(20) NOT NULL,
  `element` varchar(255) default NULL,
  KEY `FK4BF07AFB55714FB9` (`Attribute_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Attribute_validValues`
--

LOCK TABLES `Attribute_validValues` WRITE;
/*!40000 ALTER TABLE `Attribute_validValues` DISABLE KEYS */;
INSERT INTO `Attribute_validValues` VALUES (46,'Enum1'),(46,'Enum2'),(46,'Enum3'),(62,'Enum1'),(62,'Enum2'),(62,'Enum3');
/*!40000 ALTER TABLE `Attribute_validValues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NMSObject`
--

DROP TABLE IF EXISTS `NMSObject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NMSObject` (
  `id` bigint(20) NOT NULL auto_increment,
  `status` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `objectType` varchar(100) NOT NULL,
  `pathId` varchar(255) default NULL,
  `parent_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK1E9F16D351256A45` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NMSObject`
--

LOCK TABLES `NMSObject` WRITE;
/*!40000 ALTER TABLE `NMSObject` DISABLE KEYS */;
INSERT INTO `NMSObject` VALUES (1,'ACTIVE','Switch 1','switch','/1',NULL),(2,'ACTIVE','Port 1','port','/1/2',1),(3,'OFFLINE','Port 2','port','/1/3',1),(4,'ACTIVE','Switch 2','switch','/4',NULL),(5,'ACTIVE','Port 1','port','/4/5',4),(6,'OFFLINE','Port 2','port','/4/6',4),(7,'ACTIVE','Router 1','router','/7',NULL),(8,'ACTIVE','Port 1','port','/7/8',7),(9,'OFFLINE','Port 2','port','/7/9',7),(10,'ACTIVE','Router 2','router','/10',NULL),(11,'ACTIVE','Port 1','port','/10/11',10),(12,'OFFLINE','Port 2','port','/10/12',10);
/*!40000 ALTER TABLE `NMSObject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NMSObject_AttributeGroup`
--

DROP TABLE IF EXISTS `NMSObject_AttributeGroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `NMSObject_AttributeGroup` (
  `NMSObject_id` bigint(20) NOT NULL,
  `groups_id` bigint(20) NOT NULL,
  UNIQUE KEY `groups_id` (`groups_id`),
  KEY `FKA43E04F20AC188A` (`groups_id`),
  KEY `FKA43E04FEDA8477C` (`NMSObject_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `NMSObject_AttributeGroup`
--

LOCK TABLES `NMSObject_AttributeGroup` WRITE;
/*!40000 ALTER TABLE `NMSObject_AttributeGroup` DISABLE KEYS */;
INSERT INTO `NMSObject_AttributeGroup` VALUES (1,1),(1,2),(2,3),(2,4),(3,5),(3,6),(4,7),(4,8),(5,9),(5,10),(6,11),(6,12),(7,13),(7,14),(8,15),(8,16),(9,17),(9,18),(10,19),(10,20),(11,21),(11,22),(12,23),(12,24);
/*!40000 ALTER TABLE `NMSObject_AttributeGroup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-07-03  8:52:19

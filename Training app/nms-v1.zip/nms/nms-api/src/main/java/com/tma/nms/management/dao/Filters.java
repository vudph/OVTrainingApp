package com.tma.nms.management.dao;

public class Filters {
    private String m_name;
    private Object m_value;
    private Opt m_opt;
    private boolean m_and;
    private Filters m_other;
    
    
    public Filters(String name, Object value, Opt opt) {
        m_name = name;
        m_value = value;
        m_opt = opt;
    }
    
    public Filters and(Filters and) {
        m_other = and;
        m_and = true;
        return and;
    }
    
    public Filters or(Filters or) {
        m_other = or;
        m_and = false;
        return or;
    }
    

    /**
     * @return the and
     */
    public boolean isAnd() {
        return m_and;
    }

    /**
     * @return the other
     */
    public Filters getOther() {
        return m_other;
    }

    /**
     * @return the name
     */
    public String getName() {
        return m_name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        m_name = name;
    }

    /**
     * @return the value
     */
    public Object getValue() {
        return m_value;
    }

    /**
     * @param value
     *            the value to set
     */
    public void setValue(Object value) {
        m_value = value;
    }

    /**
     * @return the opt
     */
    public Opt getOpt() {
        return m_opt;
    }

    /**
     * @param opt
     *            the opt to set
     */
    public void setOpt(Opt opt) {
        m_opt = opt;
    }

    public enum Opt {
        eq, gt, lt, like
    }
}

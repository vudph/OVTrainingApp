package com.tma.nms.management.vo;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CounterVO {
	private Long m_count;

    private String m_name;

    @XmlElement
	public Long getCount() {
		return m_count;
	}

	public void setCount(Long count) {
		m_count = count;
	}

	@XmlElement
	public String getName() {
		return m_name;
	}

	public void setName(String name) {
		m_name = name;
	}
}

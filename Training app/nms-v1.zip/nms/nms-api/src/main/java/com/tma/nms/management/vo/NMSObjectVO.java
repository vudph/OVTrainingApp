package com.tma.nms.management.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import com.tma.nms.management.vo.metadata.AttributeVO;

@XmlRootElement
public class NMSObjectVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long m_id;

    private String m_name;

    private String m_objectType;

    private List<AttributeVO> m_metadata;

    private NMSObjectVO m_parent;

    private String m_status;

    @XmlElement
    public Long getId() {
        return m_id;
    }

    public void setId(Long id) {
        this.m_id = id;
    }

    @XmlElement
    public String getName() {
        return m_name;
    }

    public void setName(String name) {
        this.m_name = name;
    }

    @XmlElement
    public String getObjectType() {
        return m_objectType;
    }

    public void setObjectType(String objectType) {
        this.m_objectType = objectType;
    }

    /**
     * @return the metadata
     */
    @XmlTransient
    public List<AttributeVO> getMetadata() {
        return m_metadata;
    }

    /**
     * @param metadata
     *            the metadata to set
     */
    public void setMetadata(List<AttributeVO> metadata) {
        m_metadata = metadata;
    }

    /**
     * @return the parent
     */
    @XmlTransient
    public NMSObjectVO getParent() {
        return m_parent;
    }

    /**
     * @param parent
     *            the parent to set
     */
    public void setParent(NMSObjectVO parent) {
        m_parent = parent;
    }

    /**
     * @return the status
     */
    @XmlElement
    public String getStatus() {
        return m_status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(String status) {
        m_status = status;
    }

}

package com.tma.nms.management.vo.alarm;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.tma.nms.management.vo.NMSObjectVO;

@XmlRootElement
public class AlarmVO implements Serializable{
    private static final long serialVersionUID = 1L;
    private Long m_id;
    
    private NMSObjectVO m_srcAlarm;
    
    private String m_severity;

    /**
     * @return the srcAlarm
     */
    @XmlElement(name="source")
    public NMSObjectVO getSrcAlarm() {
        return m_srcAlarm;
    }

    /**
     * @param srcAlarm
     *            the srcAlarm to set
     */
    public void setSrcAlarm(NMSObjectVO srcAlarm) {
        m_srcAlarm = srcAlarm;
    }

    /**
     * @return the id
     */
    @XmlElement(name="alarmId")
    public Long getId() {
        return m_id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        m_id = id;
    }

    /**
     * @return the severity
     */
    @XmlElement(name="severity")
    public String getSeverity() {
        return m_severity;
    }

    /**
     * @param severity
     *            the severity to set
     */
    public void setSeverity(String severity) {
        m_severity = severity;
    }

}

package com.tma.nms.management.vo.metadata;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AttributeVO implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long m_id;

    private String m_name;

    private String m_dataType;

    private boolean m_writeable;

    private boolean m_readable;

    private String m_value;

    private List<String> m_validValues;

    private String m_regex;
    
    private String m_goupName;

    /**
     * @return the id
     */
    @XmlElement
    public Long getId() {
        return m_id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        m_id = id;
    }
    
    /**
     * @return the goupName
     */
    @XmlElement(name="group")
    public String getGoupName() {
        return m_goupName;
    }

    /**
     * @param goupName the goupName to set
     */
    public void setGoupName(String goupName) {
        m_goupName = goupName;
    }

    /**
     * @return the name
     */
    @XmlElement
    public String getName() {
        return m_name;
    }

    /**
     * @param name
     *            the name to set
     */
    public void setName(String name) {
        m_name = name;
    }

    /**
     * @return the dataType
     */
    @XmlElement(name="type")
    public String getDataType() {
        return m_dataType;
    }

    /**
     * @param dataType
     *            the dataType to set
     */
    public void setDataType(String dataType) {
        m_dataType = dataType;
    }

    /**
     * @return the writeable
     */
    @XmlElement(name="isWritable")
    public boolean isWriteable() {
        return m_writeable;
    }

    /**
     * @param writeable
     *            the writeable to set
     */
    public void setWriteable(boolean writeable) {
        m_writeable = writeable;
    }

    /**
     * @return the readable
     */
    @XmlElement(name="isReadable")
    public boolean isReadable() {
        return m_readable;
    }

    /**
     * @param readable
     *            the readable to set
     */
    public void setReadable(boolean readable) {
        m_readable = readable;
    }

    /**
     * @return the value
     */
    @XmlElement
    public String getValue() {
        return m_value;
    }

    /**
     * @param value
     *            the value to set
     */
    public void setValue(String value) {
        m_value = value;
    }

    /**
     * @return the validValues
     */
    @XmlElement
    public List<String> getValidValues() {
        return m_validValues;
    }

    /**
     * @param validValues
     *            the validValues to set
     */
    public void setValidValues(List<String> validValues) {
        m_validValues = validValues;
    }

    /**
     * @return the regex
     */
    @XmlElement(name = "regex")
    public String getRegex() {
        return m_regex;
    }

    /**
     * @param regex
     *            the regex to set
     */
    public void setRegex(String regex) {
        m_regex = regex;
    }

}

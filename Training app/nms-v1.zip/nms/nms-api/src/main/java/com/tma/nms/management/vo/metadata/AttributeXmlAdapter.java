package com.tma.nms.management.vo.metadata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlAdapter;

public class AttributeXmlAdapter extends XmlAdapter<AttributeXmlAdapter.AdaptedMap, Map<String, List<AttributeVO>>>{
    
    @XmlRootElement
    public static class AdaptedMap implements Serializable{
        private static final long serialVersionUID = 1L;
        @XmlElement(name="entries")
        public List<Entry> m_entry = new ArrayList<Entry>();
    }

    @XmlRootElement
    public static class Entry implements Serializable{
        private static final long serialVersionUID = 1L;
        @XmlElement(name="groupName")
        public String m_goupName;

        @XmlElement(name="metadatas")
        public List<AttributeVO> m_attMetadata;
    }

    @Override
    public Map<String, List<AttributeVO>> unmarshal(AdaptedMap v) throws Exception {
        Map<String, List<AttributeVO>> result = new HashMap<String, List<AttributeVO>>();
        for(Entry e : v.m_entry) {
            result.put(e.m_goupName, e.m_attMetadata);
        }
        return result;
    }

    @Override
    public AdaptedMap marshal(Map<String, List<AttributeVO>> v) throws Exception {
        AdaptedMap result = new AdaptedMap();
        for(String key : v.keySet()) {
            Entry e = new Entry();
            e.m_goupName = key;
            e.m_attMetadata = v.get(key);
            result.m_entry.add(e);
        }
        return result;
    }
}

package com.tma.nms.management.vo.metadata;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlRootElement
public class NMSObjectAttributesVO implements Serializable{
    private static final long serialVersionUID = 1L;
    /**
     * Map&lt;Group Name, List of AttributeMetadata&gt;
     */
    
    private Map<String, List<AttributeVO>> m_atts = new HashMap<String, List<AttributeVO>>();
    
    /**
     * @param group group name
     * @return list of attribute metadata by a given group name
     */
    
    public List<AttributeVO> getAttributes(String group) {
        return m_atts.get(group);
    }

    /**
     * @return the atts
     */
    @XmlElement(name="attrs")
    @XmlJavaTypeAdapter(AttributeXmlAdapter.class)
    public Map<String, List<AttributeVO>> getAtts() {
        return m_atts;
    }

    /**
     * @param atts the atts to set
     */
    public void setAtts(Map<String, List<AttributeVO>> atts) {
        m_atts = atts;
    }

    /**
     * @param group the group name of metadata
     * @param metadata
     */
    public void addAttributes(String group, AttributeVO metadata) {
        if(getAttributes(group) == null) {
            m_atts.put(group, new ArrayList<AttributeVO>());
        }
        getAttributes(group).add(metadata);
    }

//    /**
//     * @return all of attributes metadata
//     */
//    public List<AttributeMetadataVO> getAllAttributes() {
//        List<AttributeMetadataVO> results = n
//        return m_atts.values();
//    }
}

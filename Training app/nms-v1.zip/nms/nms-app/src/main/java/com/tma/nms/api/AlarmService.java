package com.tma.nms.api;

import java.util.List;

import com.tma.nms.management.dao.Ordering;
import com.tma.nms.management.dao.Paging;
import com.tma.nms.management.vo.alarm.AlarmVO;

public interface AlarmService {
    public static final String BEAN_NAME = "alarmService";
    
    
    public List<AlarmVO> fetchAllChildrenAlarms(Long objectId, Paging paging, List<Ordering> orders);
    
    public List<AlarmVO> fetchAllAlarms(Long objectId, Paging paging, List<Ordering> orders);
    
    public void updateAlarm(AlarmVO alarm);
    
    public AlarmVO createAlarm(AlarmVO alarm);
    
    public void deleteAlarm(AlarmVO alarm);
    
    public Integer countAlarms(String severity);
}

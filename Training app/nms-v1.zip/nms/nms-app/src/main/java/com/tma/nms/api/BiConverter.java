package com.tma.nms.api;


public interface BiConverter<S, T> {
    
    public T convertTo(S src);
    
    public S revertTo(T t);
}

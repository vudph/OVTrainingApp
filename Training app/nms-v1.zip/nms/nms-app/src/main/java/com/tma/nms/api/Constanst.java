package com.tma.nms.api;

public interface Constanst {
	public static final String ROOT_OBJECTID = "/root=1";
	public static final String SWITCH = "switch";
	public static final String ROUTER = "router";
	public static final String PORT = "port";
}

package com.tma.nms.api;

import java.util.List;

import com.tma.nms.management.dao.Ordering;
import com.tma.nms.management.dao.Paging;
import com.tma.nms.management.vo.CounterVO;
import com.tma.nms.management.vo.NMSObjectVO;
import com.tma.nms.management.vo.metadata.AttributeVO;

public interface NMSObjectService {
    public static final String BEAN_NAME = "deviceService";
    
    public List<NMSObjectVO> getAllNMSObjects();
    
    public List<CounterVO> getDeviceStatuses();
    
    public List<NMSObjectVO> getNMSObjects(Paging paging, List<Ordering> orders);
    
    public List<NMSObjectVO> getRootDevices();
    
    public List<NMSObjectVO> getChildren(Long parentId);
    
    public List<AttributeVO> getNMSObjectAttributes(Long objectId);
    
    public void updateMetadata(Long objectId, List<AttributeVO> lstMetadata);
    
    public Relation getRelation(Long objectId, Long anotherObjectId);
}

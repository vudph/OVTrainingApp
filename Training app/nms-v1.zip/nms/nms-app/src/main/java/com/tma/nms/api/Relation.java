package com.tma.nms.api;

public enum Relation {
	PARENT, CHILD, NO_RELATION
}

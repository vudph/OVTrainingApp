package com.tma.nms.app;

import java.util.ArrayList;
import java.util.List;

import com.tma.nms.api.AlarmService;
import com.tma.nms.api.BiConverter;
import com.tma.nms.dao.AlarmDao;
import com.tma.nms.management.alarm.AlarmSeverity;
import com.tma.nms.management.alarm.Alarm;
import com.tma.nms.management.dao.Filters;
import com.tma.nms.management.dao.Filters.Opt;
import com.tma.nms.management.dao.Ordering;
import com.tma.nms.management.dao.Paging;
import com.tma.nms.management.vo.alarm.AlarmVO;

public class AlarmServiceImpl implements AlarmService{
    
    private AlarmDao m_alarmDao;
    private BiConverter<Alarm, AlarmVO> m_alarmConverter = FactoryConverter.getConverter(Alarm.class, AlarmVO.class);
    
    public AlarmServiceImpl(AlarmDao alarmDao) {
        m_alarmDao = alarmDao;
    }

    @Override
    public List<AlarmVO> fetchAllChildrenAlarms(Long objectId, Paging paging, List<Ordering> orders) {
        List<AlarmVO> result = new ArrayList<AlarmVO>();
        for(Alarm alarm : m_alarmDao.getAllAlarmsOfChildren(objectId, paging, orders)){
            result.add(m_alarmConverter.convertTo(alarm));
        }
        return result;
    }

    @Override
    public List<AlarmVO> fetchAllAlarms(Long objectId, Paging paging, List<Ordering> orders) {
        List<AlarmVO> result = new ArrayList<AlarmVO>();
        for(Alarm alarm : m_alarmDao.getAlarmsByObjectId(objectId, paging, orders)){
            result.add(m_alarmConverter.convertTo(alarm));
        }
        return result;
    }
    
    @Override
    public void updateAlarm(AlarmVO alarm) {
        m_alarmDao.makePersistence(m_alarmConverter.revertTo(alarm));
    }

    @Override
    public AlarmVO createAlarm(AlarmVO alarm) {
        return m_alarmConverter.convertTo(m_alarmDao.makePersistence(m_alarmConverter.revertTo(alarm)));
    }

    @Override
    public void deleteAlarm(AlarmVO alarm) {
        m_alarmDao.makeTransient(m_alarmConverter.revertTo(alarm));
    }

    @Override
    public Integer countAlarms(String severity) {
        Filters f = new Filters("severity", AlarmSeverity.valueOf(severity), Opt.eq);
        return m_alarmDao.count(f);
    }
}

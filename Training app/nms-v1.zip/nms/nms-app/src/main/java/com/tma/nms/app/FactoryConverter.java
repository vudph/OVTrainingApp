package com.tma.nms.app;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.tma.nms.api.BiConverter;
import com.tma.nms.management.NMSObject;
import com.tma.nms.management.Status;
import com.tma.nms.management.alarm.AlarmSeverity;
import com.tma.nms.management.alarm.Alarm;
import com.tma.nms.management.metadata.Attribute;
import com.tma.nms.management.metadata.AttributeGroup;
import com.tma.nms.management.vo.NMSObjectVO;
import com.tma.nms.management.vo.alarm.AlarmVO;
import com.tma.nms.management.vo.metadata.AttributeVO;

public class FactoryConverter {
    @SuppressWarnings("rawtypes")
    private static Map<DoubleKey, BiConverter> m_converter = new HashMap<DoubleKey, BiConverter>();

    private static class DoubleKey {
        Class<?> tClzz;
        Class<?> sClzz;

        public <S, T> DoubleKey(Class<S> s, Class<T> t) {
            sClzz = s;
            tClzz = t;
        }
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static <S, T> BiConverter<S, T> getConverter(Class<S> sClzz, Class<T> tClzz) {
        for (Entry<DoubleKey, BiConverter> e : m_converter.entrySet()) {
            if (e.getKey().sClzz.equals(sClzz) && e.getKey().tClzz.equals(tClzz)) {
                return e.getValue();
            } else if (e.getKey().tClzz.equals(sClzz) && e.getKey().sClzz.equals(tClzz)) {
                return new BiConvertingReverter(e.getValue());
            }
        }
        return null;
    }

    @SuppressWarnings("rawtypes")
    private static class BiConvertingReverter implements BiConverter {
        private BiConverter m_wrapper;

        public BiConvertingReverter(BiConverter wrapper) {
            m_wrapper = wrapper;
        }

        @SuppressWarnings("unchecked")
        @Override
        public Object convertTo(Object src) {
            return m_wrapper.revertTo(src);
        }

        @SuppressWarnings("unchecked")
        @Override
        public Object revertTo(Object t) {
            return m_wrapper.convertTo(t);
        }

    }

    static {
        DoubleKey dk = new DoubleKey(NMSObject.class, NMSObjectVO.class);
        m_converter.put(dk, new NMSObjectConverter());
    }

    private static class NMSObjectConverter implements BiConverter<NMSObject, NMSObjectVO> {

        @Override
        public NMSObjectVO convertTo(NMSObject src) {
            NMSObjectVO nmsObjVo = new NMSObjectVO();
            nmsObjVo.setName(src.getName());
            nmsObjVo.setId(src.getId());
            nmsObjVo.setObjectType(src.getObjectType());
            
            if (src.getStatus() != null) {
            	nmsObjVo.setStatus(src.getStatus().toString());
            }
            
            return nmsObjVo;
        }

        @Override
        public NMSObject revertTo(NMSObjectVO t) {
            NMSObject nmsObj = new NMSObject();
            nmsObj.setName(t.getName());
            nmsObj.setId(t.getId());
            nmsObj.setObjectType(t.getObjectType());
            
            if (t.getStatus() != null) {
            	nmsObj.setStatus(Status.valueOf(t.getStatus()));
            }
            
            return nmsObj;
        }
    }

    static {
        DoubleKey dk = new DoubleKey(Alarm.class, AlarmVO.class);
        m_converter.put(dk, new AlarmConverter());
    }

    private static class AlarmConverter implements BiConverter<Alarm, AlarmVO> {

        @Override
        public AlarmVO convertTo(Alarm src) {
            AlarmVO alVO = new AlarmVO();
            alVO.setId(src.getId());
            alVO.setSeverity(src.getSeverity().name());
            alVO.setSrcAlarm(FactoryConverter.getConverter(NMSObject.class, NMSObjectVO.class)
                    .convertTo(src.getSrcAlarm()));
            return alVO;
        }

        @Override
        public Alarm revertTo(AlarmVO t) {
            Alarm al = new Alarm();
            al.setId(t.getId());
            al.setSeverity(AlarmSeverity.valueOf(t.getSeverity()));
            al.setSrcAlarm(FactoryConverter.getConverter(NMSObject.class, NMSObjectVO.class)
                    .revertTo(t.getSrcAlarm()));
            return al;
        }
    }

    static {
        DoubleKey dk = new DoubleKey(List.class, List.class);
        m_converter.put(dk, new NMSObjectAttributesConverter());
    }

    private static class NMSObjectAttributesConverter implements
            BiConverter<List<AttributeGroup>, List<AttributeVO>> {

        @Override
        public List<AttributeVO> convertTo(List<AttributeGroup> src) {
            List<AttributeVO> result = new ArrayList<AttributeVO>();
            for(AttributeGroup group : src){
            	List<Attribute> attributes = group.getAttributes();
            	for(Attribute attribute : attributes){
            		AttributeVO atVo = FactoryConverter.getConverter(
                            Attribute.class, AttributeVO.class).convertTo(attribute);
                    atVo.setGoupName(group.getName());
                    result.add(atVo);
            	}
            }
            
            return result;
        }

        @Override
        public List<AttributeGroup> revertTo(List<AttributeVO> t) {
        	List<AttributeGroup> rs = new ArrayList<AttributeGroup>();
        	Map<String, List<Attribute>> groups = new HashMap<String, List<Attribute>>();
            for (AttributeVO atVo : t) {
            	List<Attribute> attrs = groups.get(atVo.getGoupName());
            	if(attrs == null){
            		attrs = new ArrayList<Attribute>();
            		groups.put(atVo.getGoupName(), attrs);
            	}
            	attrs.add(FactoryConverter.getConverter(Attribute.class,
                        AttributeVO.class).revertTo(atVo));
            	
            }
            //Convert from Map to List of group
            for(String groupName : groups.keySet()){
            	AttributeGroup group = new AttributeGroup();
            	group.setName(groupName);
            	group.setAttributes(groups.get(groupName));
            	rs.add(group);
            }
            
            return rs;
        }
    }

    static {
        DoubleKey dk = new DoubleKey(Attribute.class, AttributeVO.class);
        m_converter.put(dk, new AttributeConverter());
    }

    private static class AttributeConverter implements
            BiConverter<Attribute, AttributeVO> {

        @Override
        public AttributeVO convertTo(Attribute src) {
            AttributeVO attVO = new AttributeVO();
            attVO.setId(src.getId());

            String dataType = Enum.class.getSimpleName();
            if (String.class.isAssignableFrom(src.getDataType())) {
                dataType = String.class.getSimpleName();
            } else if (Number.class.isAssignableFrom(src.getDataType())) {
                dataType = Number.class.getSimpleName();
            }

            attVO.setDataType(dataType);
            attVO.setValue(src.getValue());
            attVO.setValidValues(new ArrayList<String>(src.getValidValues()));
            attVO.setWriteable(src.getWritable());
            attVO.setReadable(src.getReadable());
            attVO.setName(src.getName());
            attVO.setRegex(src.getRegex());
            return attVO;
        }

        @Override
        public Attribute revertTo(AttributeVO t) {
            Attribute att = new Attribute();
            att.setId(t.getId());
            att.setRegex(t.getRegex());
            att.setValue(t.getValue());
            att.setName(t.getName());
            att.setReadable(t.isReadable());
            att.setWritable(t.isWriteable());
            try {
                att.setDataType(Class.forName("java.lang." + t.getDataType()));
            } catch (ClassNotFoundException e) {
            }
            return att;
        }
    }
}

package com.tma.nms.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;

import com.tma.nms.api.NMSObjectService;
import com.tma.nms.api.Relation;
import com.tma.nms.dao.NMSObjectDao;
import com.tma.nms.management.NMSObject;
import com.tma.nms.management.Status;
import com.tma.nms.management.dao.Filters;
import com.tma.nms.management.dao.Filters.Opt;
import com.tma.nms.management.dao.GenericDao;
import com.tma.nms.management.dao.GenericHibernateDao;
import com.tma.nms.management.dao.Ordering;
import com.tma.nms.management.dao.Paging;
import com.tma.nms.management.metadata.Attribute;
import com.tma.nms.management.metadata.AttributeGroup;
import com.tma.nms.management.vo.CounterVO;
import com.tma.nms.management.vo.NMSObjectVO;
import com.tma.nms.management.vo.metadata.AttributeVO;

public class NMSObjectServiceImpl implements NMSObjectService{

    private NMSObjectDao m_nmsObjectDao;
    private GenericDao<Attribute, Long> m_attributeMetadataDao;

    public NMSObjectServiceImpl(SessionFactory sessionFactory, NMSObjectDao nmsObjectDao) {
        m_nmsObjectDao = nmsObjectDao;
        m_attributeMetadataDao = new GenericHibernateDao<Attribute, Long>(sessionFactory){};
    }


    @Override
    @SuppressWarnings("unchecked")
    public List<AttributeVO> getNMSObjectAttributes(Long objectId){
        NMSObject device = m_nmsObjectDao.findById(objectId);
        return FactoryConverter.getConverter(List.class, List.class).convertTo(device.getGroups());
    }

    @Override
    public List<NMSObjectVO> getChildren(Long parentId){
        List<NMSObjectVO> result = new ArrayList<NMSObjectVO>();
        for(NMSObject device : m_nmsObjectDao.getChildren(parentId)) {
            result.add(FactoryConverter.getConverter(NMSObject.class, NMSObjectVO.class).convertTo(device));
        }
        return result;
    }

    @Override
    public List<NMSObjectVO> getRootDevices(){
        List<NMSObjectVO> result = new ArrayList<NMSObjectVO>();
        for(NMSObject device : m_nmsObjectDao.getRootDevices()) {
            result.add(FactoryConverter.getConverter(NMSObject.class, NMSObjectVO.class).convertTo(device));
        }
        return result;
    }

    @Override
    public List<NMSObjectVO> getAllNMSObjects() {
        List<NMSObjectVO> result = new ArrayList<NMSObjectVO>();
        for(NMSObject device : m_nmsObjectDao.findAll()) {
            result.add(FactoryConverter.getConverter(NMSObject.class, NMSObjectVO.class).convertTo(device));
        }
        return result;
    }

    public List<NMSObjectVO> getNMSObjects(Paging paging, List<Ordering> orders) {
        List<NMSObjectVO> result = new ArrayList<NMSObjectVO>();
        for(NMSObject device : m_nmsObjectDao.findWithPagingAndOrders(paging, orders)) {
            result.add(FactoryConverter.getConverter(NMSObject.class, NMSObjectVO.class).convertTo(device));
        }
        return result;
    }

    @Override
    public void updateMetadata(final Long objectId, final List<AttributeVO> lstMetadata) {
        NMSObject nmsObj = m_nmsObjectDao.findById(objectId);
        List<AttributeGroup> groups = nmsObj.getGroups();       
        Map<String, List<Attribute>> attributes = new HashMap<String, List<Attribute>>();
        for(AttributeGroup group : groups){
            List<Attribute> attrs = attributes.get(group.getName());
            if(attrs == null){
                attrs = new ArrayList<Attribute>();
                attributes.put(group.getName(), attrs);
            }
            attrs.addAll(group.getAttributes());
        }
        for (AttributeVO vo : lstMetadata) {
            String groupName = vo.getGoupName();
            List<Attribute> lstAttributes = attributes.get(groupName);
            if (lstAttributes != null) {
                Attribute converted = FactoryConverter.getConverter(Attribute.class, AttributeVO.class).revertTo(vo);

                Attribute tobeUpdated = null; 
                for (Attribute m : lstAttributes) {
                    if (m.getId().equals(converted.getId())) {
                        tobeUpdated = m;
                        break;
                    }
                }

                if (tobeUpdated != null) {
                    tobeUpdated.setValue(converted.getValue());
                    tobeUpdated.setDataType(converted.getDataType());
                    tobeUpdated.setName(converted.getName());
                    tobeUpdated.setReadable(converted.getReadable());
                    tobeUpdated.setWritable(converted.getWritable());
                    m_attributeMetadataDao.makePersistence(tobeUpdated);
                }
            }                   
        }
    }


    @Override
    public List<CounterVO> getDeviceStatuses() {
        List<CounterVO> results = new ArrayList<CounterVO>();

        for (Status status : Status.values()) {
            Filters f = new Filters("m_status", status, Opt.eq);
            CounterVO vo = new CounterVO();
            vo.setName(status.name());
            vo.setCount(m_nmsObjectDao.count(f).longValue());
            results.add(vo);
        }

        return results;
    }


    @Override
    public Relation getRelation(Long objectId, Long anotherObjectId) {

        NMSObject object1 = m_nmsObjectDao.findById(objectId);
        NMSObject object2 = m_nmsObjectDao.findById(anotherObjectId);

        String pathId1 = object1.getPathId();

        if(pathId1.contains(String.valueOf(anotherObjectId))){
            return Relation.CHILD;
        }

        String pathId2 = object2.getPathId();

        if(pathId2.contains(String.valueOf(objectId))){
            return Relation.PARENT;
        }

        return Relation.NO_RELATION;
    }
}

package com.tma.nms.dao;

import java.util.List;

import com.tma.nms.management.alarm.Alarm;
import com.tma.nms.management.dao.GenericDao;
import com.tma.nms.management.dao.Ordering;
import com.tma.nms.management.dao.Paging;

public interface AlarmDao extends GenericDao<Alarm, Long>{

	public List<Alarm> getAlarmsByObjectId(Long id, Paging paging, List<Ordering> orders);
	public List<Alarm> getAllAlarmsOfChildren(Long parentId, Paging paging, List<Ordering> orders);
}

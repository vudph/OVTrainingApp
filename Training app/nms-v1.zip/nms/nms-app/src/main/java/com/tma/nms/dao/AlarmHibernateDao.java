package com.tma.nms.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.tma.nms.management.NMSObject;
import com.tma.nms.management.alarm.Alarm;
import com.tma.nms.management.dao.GenericHibernateDao;
import com.tma.nms.management.dao.Ordering;
import com.tma.nms.management.dao.Paging;

public class AlarmHibernateDao extends GenericHibernateDao<Alarm, Long> implements AlarmDao{
	
	public AlarmHibernateDao(SessionFactory sessionFactory){
		
		super(sessionFactory);
	}

	@Override
	public List<Alarm> getAlarmsByObjectId(Long id, Paging paging, List<Ordering> orders) {
	    Criteria criteria = getCurrentSession().createCriteria(getPersistentClass());
        criteria.createCriteria("srcAlarm").add(
                Restrictions.or(Restrictions.like("pathId", "%" + NMSObject.PATH_CHAR + id), 
                                Restrictions.like("pathId", "%" + NMSObject.PATH_CHAR + id + NMSObject.PATH_CHAR + "%")));
        criteria.setFirstResult(paging.getStartIndex());
        criteria.setMaxResults(paging.getNumberOfRecords());
        for (Ordering order : orders) {
            if (Ordering.DESC.equals(order.getMode())) {
                criteria.addOrder(Order.desc(order.getAttribute()));
            } else if (Ordering.ASC.equals(order.getMode())) {
                criteria.addOrder(Order.asc(order.getAttribute()));
            }
        }
        return criteria.list();
	}

	@Override
	public List<Alarm> getAllAlarmsOfChildren(Long parentId, Paging paging, List<Ordering> orders) {
		Criteria criteria = getCurrentSession().createCriteria(getPersistentClass());
		criteria.createCriteria("srcAlarm").add(
		                        Restrictions.like("pathId", "%" + NMSObject.PATH_CHAR + parentId + NMSObject.PATH_CHAR + "%"));
		criteria.setFirstResult(paging.getStartIndex());
        criteria.setMaxResults(paging.getNumberOfRecords());
        for (Ordering order : orders) {
            if (Ordering.DESC.equals(order.getMode())) {
                criteria.addOrder(Order.desc(order.getAttribute()));
            } else if (Ordering.ASC.equals(order.getMode())) {
                criteria.addOrder(Order.asc(order.getAttribute()));
            }
        }
		return criteria.list();
	}
}

package com.tma.nms.dao;

import java.util.List;

import com.tma.nms.management.NMSObject;
import com.tma.nms.management.dao.GenericDao;

public interface NMSObjectDao extends GenericDao<NMSObject, Long>{

	public List<NMSObject> findByObjectType(String objectType);
	public List<NMSObject> getRootDevices();
	public List<NMSObject> getChildren(Long parentObjectId);
	
}

package com.tma.nms.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.tma.nms.management.NMSObject;
import com.tma.nms.management.dao.GenericHibernateDao;

public class NMSObjectHibernateDao extends GenericHibernateDao<NMSObject, Long> implements NMSObjectDao{

	public NMSObjectHibernateDao(SessionFactory sessionFactory){
		super(sessionFactory);
	}
	
	@SuppressWarnings("unchecked")
    @Override
	public List<NMSObject> findByObjectType(String objectType) {
		Criteria c = getCurrentSession().createCriteria(getPersistentClass());
		c.add(Restrictions.eq("objectType", objectType));
		return c.list();
	}

//	@Override
	public NMSObject findByObjectId(String objectId) {
		Criteria c = getCurrentSession().createCriteria(getPersistentClass());
		c.add(Restrictions.eq("objectId", objectId));
		return (NMSObject) c.uniqueResult();
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<NMSObject> getRootDevices() {
		Criteria c = getCurrentSession().createCriteria(getPersistentClass());
		c.add(Restrictions.isNull("parent"));
		return c.list();
	}

	@SuppressWarnings("unchecked")
    @Override
	public List<NMSObject> getChildren(Long parentObjectId) {
		Criteria c = getCurrentSession().createCriteria(getPersistentClass());
		c.add(Restrictions.eq("parent.id", parentObjectId));
		return c.list();
	}
	
	@Override
	public NMSObject makePersistence(NMSObject entity) {
	    NMSObject result = super.makePersistence(entity);
	    result.getPathId();
	    result = super.makePersistence(result);
	    return result;
	}
}
package com.tma.nms.events;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.log4j.Logger;
import org.hibernate.Hibernate;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.tma.nms.dao.AlarmDao;
import com.tma.nms.dao.NMSObjectDao;
import com.tma.nms.events.EventManagment.EventSource;
import com.tma.nms.events.EventManagment.EventType;
import com.tma.nms.management.NMSObject;
import com.tma.nms.management.alarm.AlarmSeverity;
import com.tma.nms.management.alarm.Alarm;
import com.tma.nms.management.dao.Ordering;
import com.tma.nms.management.dao.Paging;

public class AlarmAutoModifier {

	private static final Logger LOGGER = Logger
			.getLogger(AlarmAutoModifier.class);
	private AlarmDao m_alarmDao;
	private NMSObjectDao m_nmsObjectDao;
	private Timer m_timer;
	private TransactionTemplate m_transactionTemplate;

	private static final Long MAX_IN_SECOND = 10l;

	public AlarmAutoModifier(AlarmDao alarmDao, NMSObjectDao nmsObjectDao,
			TransactionTemplate transactionTemplate) {
		m_alarmDao = alarmDao;
		m_transactionTemplate = transactionTemplate;
		m_nmsObjectDao = nmsObjectDao;
		m_timer = new Timer();

	}
	
	private NMSObject getRamdomDevices(List<NMSObject> devices){
		int max = devices.size() - 1;
		int index = (int) Math.round((Math.random() * max));
		NMSObject device = devices.get(index);
		long random = Math.round(Math.random() * 10);
		if(random % 2 == 0){
			List<NMSObject> children = m_nmsObjectDao.getChildren(device.getId());
			if(children != null && !children.isEmpty()){
				max = children.size() - 1;
				index = (int) Math.round((Math.random() * max));
				return children.get(index);
			}
		}
		return device;
	}
	private AlarmSeverity getRamdomSeverity(){
		long random = Math.round(Math.random() * 10);
		return random % 2 == 0 ? AlarmSeverity.Critical : random > 5 ? AlarmSeverity.Major : AlarmSeverity.Minor;
	}

	private void update() {

		
		// Try to add more alarm
		final List<NMSObject> devices = m_transactionTemplate
				.execute(new TransactionCallback<List<NMSObject>>() {
					@Override
					public List<NMSObject> doInTransaction(
							TransactionStatus arg0) {
						return m_nmsObjectDao.getRootDevices();
					}
				});

		Alarm alarm = m_transactionTemplate.execute(new TransactionCallback<Alarm>() {
			@Override
			public Alarm doInTransaction(TransactionStatus arg0) {
				NMSObject toInsertAlarm = null;
				if (devices != null && !devices.isEmpty()) {
					toInsertAlarm = getRamdomDevices(devices);
				}
				final Alarm newAlarm = new Alarm();
				newAlarm.setSeverity(getRamdomSeverity());
				newAlarm.setSrcAlarm(toInsertAlarm);

				return m_alarmDao.makePersistence(newAlarm);
			}
		});
		//Send event
		EventManagment.getInstance().sendEvent(EventType.create, EventSource.alarm, alarm.getSrcAlarm().getId().toString());

		// Try to delete an alarm
		final int from = (int) (Math.random() * 100);
		final Alarm toDelete = m_transactionTemplate
				.execute(new TransactionCallback<Alarm>() {
					@Override
					public Alarm doInTransaction(TransactionStatus arg0) {
						NMSObject toInsertAlarm = null;
						if (devices != null && !devices.isEmpty()) {
							toInsertAlarm = devices.get(0);
							Paging paging = new Paging();
							paging.setStartIndex(from);
							paging.setNumberOfRecords(1);
							List<Ordering> orders = new ArrayList<Ordering>();
							List<Alarm> alarms = m_alarmDao.getAlarmsByObjectId(toInsertAlarm.getId(), paging, orders);
							if(alarms != null && !alarms.isEmpty()){
								Alarm alarm = alarms.get(0);
								Hibernate.initialize(alarm);
								return alarm;
							}else{
								return null;
							}
						}else{
							return null;
						}
					}
				});
		if (toDelete != null) {
			m_transactionTemplate.execute(new TransactionCallback<Object>() {
				@Override
				public Object doInTransaction(TransactionStatus arg0) {
					m_alarmDao.makeTransient(toDelete);
					//Send event
					EventManagment.getInstance().sendEvent(EventType.delete, EventSource.alarm, toDelete.getSrcAlarm().getId().toString());
					return null;
				}
			});

		}
		LOGGER.info("Alarm auto-modifier run..");

	}

	public void init() {
		Long period = MAX_IN_SECOND * 1000;
		m_timer.schedule(new TimerTask() {

			@Override
			public void run() {
				update();

			}
		}, 0, period);
	}

	public void close() {
		m_timer.cancel();
	}
}

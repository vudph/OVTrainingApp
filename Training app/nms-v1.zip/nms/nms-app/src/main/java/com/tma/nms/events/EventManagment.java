package com.tma.nms.events;

import org.glassfish.jersey.media.sse.EventOutput;
import org.glassfish.jersey.media.sse.OutboundEvent;
import org.glassfish.jersey.media.sse.SseBroadcaster;

public class EventManagment {
    private static final SseBroadcaster BROADCASTER = new SseBroadcaster();
    
    private static EventManagment instance;
    
    private EventManagment(){}
    
    public static synchronized EventManagment getInstance() {
        if(instance == null) {
            instance = new EventManagment();
        }
        return instance;
    }
    
    public void registerEvent(EventOutput evOut) {
        BROADCASTER.add(evOut);
    }
    
    public void sendEvent(EventType type, EventSource evtSrc, Object data) {
        OutboundEvent.Builder builder = new OutboundEvent.Builder();
        builder.name(type.name());
        builder.id(evtSrc.name());
        builder.data(data.getClass(), data);
        OutboundEvent outEvent = builder.build();
        BROADCASTER.broadcast(outEvent);
    }
    
    public enum EventType {
        update,
        delete,
        create
    }
    
    public enum EventSource {
        alarm,
        metadata,
        dv
    }
}

package com.tma.nms.rsrcs;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import com.tma.nms.api.AlarmService;
import com.tma.nms.ctx.NMSAppContext;
import com.tma.nms.events.EventManagment;
import com.tma.nms.events.EventManagment.EventSource;
import com.tma.nms.events.EventManagment.EventType;
import com.tma.nms.management.alarm.AlarmSeverity;
import com.tma.nms.management.dao.Ordering;
import com.tma.nms.management.dao.Paging;
import com.tma.nms.management.vo.CounterVO;
import com.tma.nms.management.vo.alarm.AlarmVO;

@Path("/devices")
public class AlarmRSrc {
    private AlarmService m_alarmService;
    
    public AlarmRSrc() {
        m_alarmService = NMSAppContext.getService(AlarmService.class, AlarmService.BEAN_NAME);
    }
    
    @GET
    @Path("{id}/alarms")
    @Produces(MediaType.APPLICATION_JSON)
    public List<AlarmVO> getAlarms(
            @PathParam("id") Long nmsObjectId, 
            @DefaultValue("0")
            @QueryParam("start") Integer startIndex,
            @DefaultValue(Integer.MAX_VALUE + "")
            @QueryParam("max") Integer maxRecords,
            @QueryParam("orderDesc") List<String> orderDesc, 
            @QueryParam("orderAsc") List<String> orderAsc) {
        Paging paging = new Paging();
        paging.setNumberOfRecords(maxRecords);
        paging.setStartIndex(startIndex);

        List<Ordering> orders = new ArrayList<Ordering>();
        if (orderDesc != null) {
            for (String attribute : orderDesc) {
                Ordering order = new Ordering();
                order.setAttribute(attribute);
                order.setMode(Ordering.DESC);
                orders.add(order);
            }
        }
        if (orderAsc != null) {
            for (String attribute : orderAsc) {
                Ordering order = new Ordering();
                order.setAttribute(attribute);
                order.setMode(Ordering.ASC);
                orders.add(order);
            }
        }
        return m_alarmService.fetchAllAlarms(nmsObjectId, paging, orders);
    }
    
    @GET
    @Path("/alarms/status")
    @Produces(MediaType.APPLICATION_JSON)
    public List<CounterVO> getAlarmStatus() {
        List<CounterVO> result = new ArrayList<CounterVO>();
        for(AlarmSeverity alSer : AlarmSeverity.values()) {
            CounterVO ctVo = new CounterVO();
            ctVo.setName(alSer.name());
            ctVo.setCount((long) m_alarmService.countAlarms(alSer.name()).intValue());
            result.add(ctVo);
        }
        return result;
    }
    
    @GET
    @Path("/alarms/count/{severity}")
    @Produces(MediaType.TEXT_PLAIN)
    public int countAlarm(@PathParam("severity") String severity) {
        return m_alarmService.countAlarms(severity);
    }
    
    @GET
    @Path("/alarms/severities")
    @Produces(MediaType.APPLICATION_JSON)
    public AlarmSeverity[] getAllSeverity() {
        return AlarmSeverity.values();
    }
    
    @PUT
    @Path("/alarms")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateAlarm(AlarmVO alarm) {
        m_alarmService.updateAlarm(alarm);
        EventManagment.getInstance().sendEvent(EventType.update, EventSource.alarm, alarm);
    }

    @POST
    @Path("{id}/alarms")
    @Consumes(MediaType.APPLICATION_JSON)
    public void createAlarm(AlarmVO alarm) {
        m_alarmService.createAlarm(alarm);
        EventManagment.getInstance().sendEvent(EventType.create, EventSource.alarm, alarm);
    }

    @DELETE
    @Path("{id}/alarms")
    @Consumes(MediaType.APPLICATION_JSON)
    public void deleteAlarm(AlarmVO alarm) {
        m_alarmService.deleteAlarm(alarm);
        EventManagment.getInstance().sendEvent(EventType.delete, EventSource.alarm, alarm);
    }
}

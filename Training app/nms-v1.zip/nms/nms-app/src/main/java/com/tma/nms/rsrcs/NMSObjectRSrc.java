package com.tma.nms.rsrcs;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.media.sse.EventOutput;
import org.glassfish.jersey.media.sse.SseFeature;

import com.tma.nms.api.NMSObjectService;
import com.tma.nms.ctx.NMSAppContext;
import com.tma.nms.events.EventManagment;
import com.tma.nms.events.EventManagment.EventSource;
import com.tma.nms.events.EventManagment.EventType;
import com.tma.nms.management.vo.CounterVO;
import com.tma.nms.management.vo.NMSObjectVO;
import com.tma.nms.management.vo.metadata.AttributeVO;

@Path("/devices")
public class NMSObjectRSrc {
    private NMSObjectService m_dvService;

    public NMSObjectRSrc() {
        m_dvService = NMSAppContext.getService(NMSObjectService.class, NMSObjectService.BEAN_NAME);
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<NMSObjectVO> getRootNMSObjects() {
        return m_dvService.getRootDevices();
    }
    
    @GET
    @Path("status")
    @Produces(MediaType.APPLICATION_JSON)
    public List<CounterVO> getDeviceStatusData() {
        return m_dvService.getDeviceStatuses();
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void createNMSObject(@QueryParam("parentId") Long parentId, NMSObjectVO newNMSObject) {
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateNMSObject(NMSObjectVO newNMSObject) {
    }

    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public List<NMSObjectVO> getChilds(@PathParam("id") Long parentId) {
        return m_dvService.getChildren(parentId);
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("{id}/attributes")
    public List<AttributeVO> getMetadata(@PathParam("id") Long id) {
        return m_dvService.getNMSObjectAttributes(id);
    }

    @PUT
    @Path("{id}/attributes")
    @Consumes(MediaType.APPLICATION_JSON)
    public void updateMetadata(@PathParam("id") Long id, List<AttributeVO> metadata) {
    	m_dvService.updateMetadata(id, metadata);
    	EventManagment.getInstance().sendEvent(EventType.update, EventSource.metadata, id);
    }

    
    @GET
    @Path("events")
    @Produces(SseFeature.SERVER_SENT_EVENTS)
    public EventOutput itemEvents() {
        final EventOutput eventOutput = new EventOutput();
        EventManagment.getInstance().registerEvent(eventOutput);
        return eventOutput;
    }
    @GET
    @Path("relation")
    public String getRelation(@QueryParam("id1") Long objectId, @QueryParam("id2") Long anotherObjectId){
    	return m_dvService.getRelation(objectId, anotherObjectId).toString();
    }
}

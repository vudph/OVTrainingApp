package com.tma.nms.rsrcs;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.media.sse.SseFeature;
import org.glassfish.jersey.server.ResourceConfig;

@ApplicationPath("/api")
public class NMSResourceCfg extends ResourceConfig{
    public NMSResourceCfg() {
        packages(NMSObjectRSrc.class.getPackage().getName());
        
        register(SseFeature.class);
        register(JacksonFeature.class);
    }
}

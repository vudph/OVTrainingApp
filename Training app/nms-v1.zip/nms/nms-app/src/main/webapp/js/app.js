'use strict';

var nmsDemo = angular.module('nmsDemo', ['nmsDemo.chartDirectives', 'nmsDemo.treeDirectives', 'nmsDemo.utilService', 'nmsDemo.restServices', 'nmsDemo.detailsDirective', 'ui.bootstrap', 'ngTable', 'jm.i18next']);

//Route
nmsDemo.config(function($routeProvider) {
    $routeProvider.when('/content', {
        templateUrl : 'partials/content.html',
        controller : 'ContentCtrl'
    });

    $routeProvider.otherwise({
        templateUrl : 'partials/chart.html',
        controller : 'ChartCtrl',
        redirectTo : '/'
    });
});

//i18next
nmsDemo.config(function ($i18nextProvider) {
    $i18nextProvider.options = {
        lng: 'en',
        fallbackLng: 'en',
        resGetPath: 'locales/__lng__/__ns__.json'
    };
});
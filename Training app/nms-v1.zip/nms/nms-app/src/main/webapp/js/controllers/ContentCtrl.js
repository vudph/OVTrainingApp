'use strict';

nmsDemo.controller('ContentCtrl', function($scope, $routeParams, utilService, deviceService, alarmService, attributesService, relationService, ngTableParams, $filter){
   
    $scope.selectedTab = null; 
    $scope.selectedObj = null;
    
    $scope.tabConfig = { 
        title: "tabConfig", 
        load: function() {
            console.log('Select tab config');
            
            $scope.$emit("ALARM_LABEL", { visible: false });
            
            $scope.currentRoute = "config";
            $scope.selectedTab = this;
            if($scope.selectedObj != null) {
                $scope.objDetails = attributesService.get({id: $scope.selectedObj.key}, function() {
                    console.log('Load config of ', $scope.selectedObj);
                    $scope.detailsData = utilService.convertToDetailsData($scope.objDetails, "group");
                });
            }
        }
    };
    
    $scope.tabAlarm = { 
        title: "tabAlarm",
        load: function() {
            console.log('Select tab alarm');
            $scope.currentRoute = "alarm";
            $scope.selectedTab = this;
            if($scope.selectedObj != null) {
                var alarms = alarmService.get({id: $scope.selectedObj.key}, function(){
                    console.log('Load alarm of ', $scope.selectedObj);
                    console.log('Alarms: ', alarms)
                    $scope.alarms = alarms;
                    
                    $scope.alarms = $scope.tableParams.sorting ? $filter('orderBy')($scope.alarms, $scope.tableParams.orderBy()) : $scope.alarms;
                    
                    $scope.$emit("ALARM_LABEL", { visible: true, text: $scope.alarms.length });
                });
            }
        }
    };

    $scope.$on('$routeChangeSuccess', function(event, routeData) {
        console.log('routeChange success')
        $scope.currentRoute = $routeParams['tab'];

        if (typeof ($scope.currentRoute) === 'undefined') {
            console.log("default to config tab");
            $scope.currentRoute = "config";
        }

        if ($scope.currentRoute === "config") {
            $scope.selectedTab = $scope.tabConfig;
        } else {
            $scope.selectedTab = $scope.tabAlarm;
        }
    }); 

    // Tree View
    $scope.treeData = {
        data: [],
        
        onSelect : function(node){
//      function getFullPath(node) {
//          if (!node.parent.data.title) {
//              return node.data.title;
//          } else {
//              return getFullPath(node.parent) + "/" + node.data.title;
//          }
//      }
        
            $scope.selectedObj = node.data;
            $scope.selectedTab.load();
        },
        
        onExpand : function(node){
            var children = deviceService.get({ id: node.data.key }, function(){
                children.forEach(function (element, index, array){
                   element.title = element.name;
                   element.key = element.id;
                });
                node.setLazyNodeStatus(DTNodeStatus_Ok);
                node.addChild(children);
            });
        },
    };

    // Table View
    $scope.alarms = [];
    
    $scope.tableParams = new ngTableParams({
        sorting: {
            alarmId: 'asc'     // initial sorting
        },
        counts: [],
    });
 
    // watch for changes of parameters
    $scope.$watch('tableParams', function(params) {
        // use build-in angular filter
        $scope.alarms = params.sorting ? $filter('orderBy')($scope.alarms, params.orderBy()) : $scope.alarms;
    }, true);
	
    
    // update
    $scope.updateMetadata = function () {
        console.log("update metadata!!");

        console.log($scope.detailsData);

        utilService.updateDetails($scope.detailsData, $scope.objDetails, "group");

        console.log($scope.objDetails);

        attributesService.put({id: $scope.selectedObj.key}, $scope.objDetails, function () {
            alert("Update successfully!");
        });
    };
    
    
    // Load devices
    var allDevices = deviceService.query({}, function(){
        allDevices.forEach(function (element, index, array){
           element.title = element.name;
           element.key = element.id;
           element.isLazy = true; 
        });
        $scope.treeData.data = allDevices;
    });
    
    $scope.$on("ALARM", function(event, args){
        console.log("---------------------------------------");
        // there is alarm update! update the alarm tab!
        if ($scope.selectedTab === $scope.tabAlarm) {
            console.log('======= MEANWHILE, IN ALARM TAB =======');
            console.log("Selected: " +  ($scope.selectedObj ? ("" + $scope.selectedObj.key) : "null"));
            console.log("Updated: " + args['id'])
            if ($scope.selectedObj) {
                var selectedId = $scope.selectedObj.key;
                var updatedId = args['id'];
                if (selectedId === updatedId) {
                    $scope.tabAlarm.load();
                } else {
                    relationService.getRelation(selectedId, updatedId).success(function(data, status) {
                        if (data === "PARENT") {
                            console.log("SelectedId is a parent of UpdatedId");
                            $scope.tabAlarm.load();
                        }
                    });
                }
            }
        }
        console.log("---------------------------------------");    
    });
    
    $scope.$on('$destroy', function() {
        $scope.$emit("ALARM_LABEL", { visible: false });
    });
});

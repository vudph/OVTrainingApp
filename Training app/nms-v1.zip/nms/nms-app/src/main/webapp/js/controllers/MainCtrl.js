'use strict';

nmsDemo.controller('MainCtrl', function($scope, $i18next, utilService, deviceService, attributesService, alarmService) {
    $scope.liveUpdateChecked = false;
    
    //change language
    $scope.langs= [
        {id:'en', name: 'english', selected: true},
        {id:'vi', name: 'vietnamese'}
    ];
    
    $scope.changeLang = function($event) {
        $i18next.options.lng=$scope.selectedLang;
    };
    
    $scope.selectedLang='en';
    
    $scope.$on('$viewContentLoaded', function(event, routeData) {
        var lngOpts = angular.element('#lngOpts');
        if(lngOpts[0].value !== $scope.selectedLang) {
            lngOpts[0].value=$scope.selectedLang;
        }
    }); 
    
    // live update
    $scope.sendAlarmsUpdate = function(event) {
        $scope.$broadcast("ALARM", {id : event.data});
    }
    
    $scope.$watch('liveUpdateChecked', function(newVal){
        if (newVal) {
            console.log("TURN ON SSE!")
            $scope.createSseSource();
        } else {
            console.log("TURN OFF SSE!")
            if ($scope.sseSource) {
                console.log("Close connection!")    
                $scope.sseSource.close();
                delete $scope.sseSource;
            }
        } 
    });
    
    $scope.createSseSource = function() {
        if (typeof(EventSource) !== "undefined") {
            $scope.sseSource = new EventSource("api/devices/events");
            
            $scope.sseSource.onmessage = function (event) {
                console.log('------ ON MESSAGE--------'); 
                console.log(event);
                console.log('------ END ON MESSAGE--------');
            };
            
            $scope.sseSource.addEventListener("create", function(event) {
                console.log('Received CREATE event');
                console.log(event);
                $scope.sendAlarmsUpdate(event);
            }, false);
            
            $scope.sseSource.addEventListener("update", function(event) {
                console.log('Received UPDATE event');
                console.log(event);
                $scope.sendAlarmsUpdate(event);
            }, false);
            
            $scope.sseSource.addEventListener("delete", function(event) {
                console.log('Received DELETE event');
                console.log(event);
                $scope.sendAlarmsUpdate(event);
            }, false);
            
            $scope.sseSource.onopen = function (event) {
                console.log("-------- EVENT SOURCE OPENED --------");
            };
            
            $scope.sseSource.onerror = function (event) {
                console.log('-------- RECEIVED ERROR EVENT --------');
                console.log(event);
                console.log("-------- END RECEIVED ERROR EVENT --------");
            };
        }
    }
    
    // alarm label    
    $scope.alarmLabelVisible = false;
    $scope.alarmLabelText = 0;
    
    $scope.$on("ALARM_LABEL", function(event, args){
        console.log("=========== UPDATE LABEL VISIBILITY ================");
        $scope.alarmLabelVisible = args['visible'];
        if ($scope.alarmLabelVisible) {
            $scope.alarmLabelText = args['text'];
        }
    });
});

'use strict';

/* jasmine specs for directives go here */
describe('NMS Training App directives', function() {

    beforeEach(module('nmsDemo.treeDirectives'));

    describe('nmsTree', function() {

        it('should have 2 div element appended', function() {
            return inject(function($compile, $rootScope) {

                var scope = $rootScope.$new();

                scope.treeData = {
                    data : []
                };
                var element = $compile('<nms-tree model="treeData"></nms-tree>')(scope);
                // scope.$apply(function() {
                // });

                return expect(element.children().length).toEqual(2);
            });

        })
    })
});

package com.tma.nms.app;

import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.tma.nms.dao.AlarmDao;
import com.tma.nms.management.NMSObject;
import com.tma.nms.management.alarm.AlarmSeverity;
import com.tma.nms.management.alarm.Alarm;
import com.tma.nms.management.dao.Filters;
import com.tma.nms.management.dao.Ordering;
import com.tma.nms.management.dao.Paging;
import com.tma.nms.management.vo.NMSObjectVO;
import com.tma.nms.management.vo.alarm.AlarmVO;

public class AlarmServiceImplTest {
    private AlarmServiceImpl m_alarmServiceImpl;
    private AlarmDao m_alarmDao;

    @Before
    public void setUp() {
        m_alarmDao = mock(AlarmDao.class);
        m_alarmServiceImpl = new AlarmServiceImpl(m_alarmDao);
    }

    @Test
    public void fetchAllChildrenAlarms() {
        final Long objectId = 1l;
        Paging paging = new Paging();
        paging.setNumberOfRecords(2);
        paging.setStartIndex(0);
        List<Ordering> orders = new ArrayList<Ordering>();

        //test with result less than paging
        List<Alarm> mockRslt = new ArrayList<Alarm>();
        Alarm alrm = new Alarm();
        alrm.setId(1l);
        alrm.setSeverity(AlarmSeverity.Critical);
        alrm.setSrcAlarm(new NMSObject());
        alrm.getSrcAlarm().setId(1l);
        alrm.getSrcAlarm().setName("Switch");
        mockRslt.add(alrm);
        when(m_alarmDao.getAllAlarmsOfChildren(objectId, paging, orders)).thenReturn(mockRslt);
        List<AlarmVO> result = m_alarmServiceImpl.fetchAllChildrenAlarms(objectId, paging, orders);
        assertEquals(1, result.size());
        assertEquals((Long)1l, result.get(0).getId());
        assertEquals(AlarmSeverity.Critical.name(), result.get(0).getSeverity());

    }

    @SuppressWarnings("unchecked")
    @Test
    public void fetchAllChildrenAlarms1() {
        //test with result greater than paging
        final List<Alarm> mockRslt = new ArrayList<Alarm>();
        NMSObject parent = new NMSObject();
        parent.setId(1l);
        parent.setName("Root");
        
        Alarm alrm = new Alarm();
        alrm.setId(1l);
        alrm.setSeverity(AlarmSeverity.Critical);
        alrm.setSrcAlarm(new NMSObject());
        alrm.getSrcAlarm().setId(2l);
        alrm.getSrcAlarm().setName("Switch");
        alrm.getSrcAlarm().setParent(parent);
        mockRslt.add(alrm);
        
        alrm = new Alarm();
        alrm.setId(2l);
        alrm.setSeverity(AlarmSeverity.Major);
        alrm.setSrcAlarm(new NMSObject());
        alrm.getSrcAlarm().setId(3l);
        alrm.getSrcAlarm().setName("Switch 1");
        alrm.getSrcAlarm().setParent(parent);
        mockRslt.add(alrm);

        alrm = new Alarm();
        alrm.setId(3l);
        alrm.setSeverity(AlarmSeverity.Minor);
        alrm.setSrcAlarm(new NMSObject());
        alrm.getSrcAlarm().setId(4l);
        alrm.getSrcAlarm().setName("Switch");
        alrm.getSrcAlarm().setParent(parent);
        mockRslt.add(alrm);

        when(m_alarmDao.getAllAlarmsOfChildren(anyLong(), (Paging) anyObject(), (List<Ordering>) anyObject())).thenAnswer(new Answer< List<Alarm>>() {
            @Override
            public List<Alarm> answer(InvocationOnMock invocation) throws Throwable {
                Paging paging = (Paging) invocation.getArguments()[1];
                int toIndex = paging.getNumberOfRecords() + paging.getStartIndex();
                int startIndex = paging.getStartIndex();
                if(toIndex > mockRslt.size()) {
                    toIndex = mockRslt.size();
                }
                if(startIndex > mockRslt.size()) {
                    return Collections.emptyList();
                }
                return mockRslt.subList(startIndex, toIndex);
            }
        });

        {
            Long objectId = 1l;
            Paging paging = new Paging();
            paging.setNumberOfRecords(2);
            paging.setStartIndex(0);
            List<Ordering> orders = new ArrayList<Ordering>();
            List<AlarmVO> result = m_alarmServiceImpl.fetchAllChildrenAlarms(objectId, paging, orders);
            assertEquals(2, result.size());
            assertEquals((Long)2l, result.get(0).getSrcAlarm().getId());
            assertEquals(AlarmSeverity.Critical.name(), result.get(0).getSeverity());
            for(AlarmVO alVo : result) {
                assertTrue(alVo.getSrcAlarm().getId() != objectId);
            }
        }
        
        {
            Long objectId = 1l;
            Paging paging = new Paging();
            paging.setNumberOfRecords(3);
            paging.setStartIndex(1);
            List<Ordering> orders = new ArrayList<Ordering>();
            List<AlarmVO> result = m_alarmServiceImpl.fetchAllChildrenAlarms(objectId, paging, orders);
            assertEquals(2, result.size());
            assertEquals((Long)3l, result.get(0).getSrcAlarm().getId());
            assertEquals(AlarmSeverity.Major.name(), result.get(0).getSeverity());
            for(AlarmVO alVo : result) {
                assertTrue(alVo.getSrcAlarm().getId() != objectId);
            }
        }
        
        {
            Long objectId = 1l;
            Paging paging = new Paging();
            paging.setNumberOfRecords(3);
            paging.setStartIndex(0);
            List<Ordering> orders = new ArrayList<Ordering>();
            List<AlarmVO> result = m_alarmServiceImpl.fetchAllChildrenAlarms(objectId, paging, orders);
            assertEquals(3, result.size());
            assertEquals((Long)2l, result.get(0).getSrcAlarm().getId());
            assertEquals(AlarmSeverity.Critical.name(), result.get(0).getSeverity());
            for(AlarmVO alVo : result) {
                assertTrue(alVo.getSrcAlarm().getId() != objectId);
            }
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    public void fetchAllAlarms() {
        final List<Alarm> mockRslt = new ArrayList<Alarm>();
        NMSObject parent = new NMSObject();
        parent.setId(1l);
        parent.setName("Root");
        
        Alarm alrm = new Alarm();
        alrm.setId(1l);
        alrm.setSeverity(AlarmSeverity.Critical);
        alrm.setSrcAlarm(new NMSObject());
        alrm.getSrcAlarm().setId(2l);
        alrm.getSrcAlarm().setName("Switch");
        alrm.getSrcAlarm().setParent(parent);
        mockRslt.add(alrm);
        
        alrm = new Alarm();
        alrm.setId(2l);
        alrm.setSeverity(AlarmSeverity.Major);
        alrm.setSrcAlarm(new NMSObject());
        alrm.getSrcAlarm().setId(3l);
        alrm.getSrcAlarm().setName("Switch 1");
        alrm.getSrcAlarm().setParent(parent);
        mockRslt.add(alrm);

        alrm = new Alarm();
        alrm.setId(3l);
        alrm.setSeverity(AlarmSeverity.Minor);
        alrm.setSrcAlarm(parent);
        mockRslt.add(alrm);

        when(m_alarmDao.getAlarmsByObjectId(anyLong(), (Paging) anyObject(), (List<Ordering>) anyObject())).thenAnswer(new Answer< List<Alarm>>() {
            @Override
            public List<Alarm> answer(InvocationOnMock invocation) throws Throwable {
                Paging paging = (Paging) invocation.getArguments()[1];
                int toIndex = paging.getNumberOfRecords() + paging.getStartIndex();
                int startIndex = paging.getStartIndex();
                if(toIndex > mockRslt.size()) {
                    toIndex = mockRslt.size();
                }
                if(startIndex > mockRslt.size()) {
                    return Collections.emptyList();
                }
                return mockRslt.subList(startIndex, toIndex);
            }
        });
        
        Long objectId = 1l;
        Paging paging = new Paging();
        paging.setNumberOfRecords(3);
        paging.setStartIndex(0);
        List<Ordering> orders = new ArrayList<Ordering>();
        List<AlarmVO> result = m_alarmServiceImpl.fetchAllAlarms(objectId, paging, orders);
        
        assertEquals(3, result.size());
        
        assertEquals((Long)2l, result.get(0).getSrcAlarm().getId());
        assertEquals(AlarmSeverity.Critical.name(), result.get(0).getSeverity());
        
        assertEquals((Long)3l, result.get(1).getSrcAlarm().getId());
        assertEquals(AlarmSeverity.Major.name(), result.get(1).getSeverity());
        
        assertEquals(parent.getId(), result.get(2).getSrcAlarm().getId());
        assertEquals(AlarmSeverity.Minor.name(), result.get(2).getSeverity());
    }

    @Test
    public void updateAlarm() {
        AlarmVO alarmVo = new AlarmVO();
        alarmVo.setId(1l);
        alarmVo.setSrcAlarm(new NMSObjectVO());
        alarmVo.getSrcAlarm().setId(1l);
        alarmVo.getSrcAlarm().setName("Router");
        alarmVo.setSeverity(AlarmSeverity.Critical.name());
        when(m_alarmDao.makePersistence((Alarm) anyObject())).thenAnswer(new Answer<Alarm>() {
            @Override
            public Alarm answer(InvocationOnMock invocation) throws Throwable {
                Alarm alarm = (Alarm) invocation.getArguments()[0];
                assertEquals((Long)1l, alarm.getId());
                assertEquals(AlarmSeverity.Critical, alarm.getSeverity());
                return alarm;
            }
        });
        m_alarmServiceImpl.updateAlarm(alarmVo);
    }

    @Test
    public void createAlarm() {
        
        AlarmVO alarmVo = new AlarmVO();
        alarmVo.setId(1l);
        alarmVo.setSrcAlarm(new NMSObjectVO());
        alarmVo.getSrcAlarm().setId(1l);
        alarmVo.getSrcAlarm().setName("Router");
        alarmVo.setSeverity(AlarmSeverity.Critical.name());
        when(m_alarmDao.makePersistence((Alarm) anyObject())).thenAnswer(new Answer<Alarm>() {
            @Override
            public Alarm answer(InvocationOnMock invocation) throws Throwable {
                Alarm alarm = (Alarm) invocation.getArguments()[0];
                assertEquals((Long)1l, alarm.getId());
                assertEquals(AlarmSeverity.Critical, alarm.getSeverity());
                return alarm;
            }
        });
        m_alarmServiceImpl.createAlarm(alarmVo);
    }

    @Test
    public void deleteAlarm() {
        AlarmVO alarmVo = new AlarmVO();
        alarmVo.setId(1l);
        alarmVo.setSrcAlarm(new NMSObjectVO());
        alarmVo.getSrcAlarm().setId(1l);
        alarmVo.getSrcAlarm().setName("Router");
        alarmVo.setSeverity(AlarmSeverity.Critical.name());
        when(m_alarmDao.makeTransient((Alarm) anyObject())).thenAnswer(new Answer<Alarm>() {
            @Override
            public Alarm answer(InvocationOnMock invocation) throws Throwable {
                Alarm alarm = (Alarm) invocation.getArguments()[0];
                assertEquals((Long)1l, alarm.getId());
                assertEquals(AlarmSeverity.Critical, alarm.getSeverity());
                return alarm;
            }
        });
        m_alarmServiceImpl.deleteAlarm(alarmVo);
    }

    @Test
    public void countAlarms() {
        when(m_alarmDao.count((Filters) anyObject())).thenAnswer(new Answer<Integer>() {
            @Override
            public Integer answer(InvocationOnMock invocation) throws Throwable {
                Filters f = (Filters) invocation.getArguments()[0];
                if("severity".equals(f.getName())) {
                    AlarmSeverity severity = (AlarmSeverity) f.getValue();
                    switch(severity) {
                    case Critical:
                        return 10;
                    case Major:
                        return 20;
                    case Minor:
                        return 30;
                    }
                }
                return 0;
            }
        });
        
        assertEquals((Integer)10, m_alarmServiceImpl.countAlarms("Critical"));
        assertEquals((Integer)20, m_alarmServiceImpl.countAlarms("Major"));
        assertEquals((Integer)30, m_alarmServiceImpl.countAlarms("Minor"));
        try {
            m_alarmServiceImpl.countAlarms("no severity");
            fail("exception is expected");
        } catch(Exception e) {}
    }
}

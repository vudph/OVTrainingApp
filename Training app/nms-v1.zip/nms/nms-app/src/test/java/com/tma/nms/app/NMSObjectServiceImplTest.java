package com.tma.nms.app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.tma.nms.dao.NMSObjectDao;
import com.tma.nms.management.NMSObject;
import com.tma.nms.management.Status;
import com.tma.nms.management.dao.Filters;
import com.tma.nms.management.vo.CounterVO;
import com.tma.nms.management.vo.NMSObjectVO;

public class NMSObjectServiceImplTest{
    private NMSObjectServiceImpl m_nmsObjectServiceImpl;
    private NMSObjectDao m_nmsObjectDao;
    
    @Before
    public void setUp() {
        SessionFactory sessionFactory = mock(SessionFactory.class);
        m_nmsObjectDao = mock(NMSObjectDao.class);
        m_nmsObjectServiceImpl = new NMSObjectServiceImpl(sessionFactory, m_nmsObjectDao);
    }
    
    @Test
    public void getAllNMSObjects() {
        List<NMSObject> daoResult = new ArrayList<NMSObject>();
        when(m_nmsObjectDao.findAll()).thenReturn(daoResult);
        List<NMSObjectVO> result = m_nmsObjectServiceImpl.getAllNMSObjects();
        assertTrue(result.isEmpty());
    }
    
    @Test
    public void getAllNMSObjects1() {
        List<NMSObject> daoResult = new ArrayList<NMSObject>();
        NMSObject nms = new NMSObject();
        nms.setId(1l);
        nms.setName("Test");
        daoResult.add(nms);
        when(m_nmsObjectDao.findAll()).thenReturn(daoResult);
        List<NMSObjectVO> result = m_nmsObjectServiceImpl.getAllNMSObjects();
        assertEquals(1, result.size());
        assertEquals((Long)1l, result.get(0).getId());
    }
    
    @Test
    public void getDeviceStatuses() {
        when(m_nmsObjectDao.count((Filters) anyObject())).thenAnswer(new Answer<Integer>() {
            @Override
            public Integer answer(InvocationOnMock invocation) throws Throwable {
                Filters f = (Filters) invocation.getArguments()[0];
                if("m_status".equals(f.getName())) {
                    Status severity = (Status) f.getValue();
                    switch(severity) {
                    case OFFLINE:
                        return 10;
                    case ACTIVE:
                        return 20;
                    }
                }
                return 0;
            }
        });
        
        List<CounterVO> result = m_nmsObjectServiceImpl.getDeviceStatuses();
        assertEquals(2, result.size());
        for(CounterVO c : result) {
            Status sts = Status.valueOf(c.getName());
            switch(sts) {
            case OFFLINE:
                assertEquals(10, c.getCount().longValue());
                break;
            case ACTIVE:
                assertEquals(20, c.getCount().longValue());
                break;
            }
        }
    }

    public void getNMSObjects() {
    }

    public void getRootDevices() {
    }

    public void getChildren() {
    }

    public void getNMSObjectAttributes() {
    }

    public void updateMetadata() {
    }

    public void getRelation() {
    }

}

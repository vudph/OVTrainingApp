package com.tma.nms.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import junit.framework.Assert;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.junit.After;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.transaction.support.TransactionTemplate;

@ContextConfiguration(locations = { "classpath:testApplicationContext.xml" })
public class AbstractDaoTest extends AbstractJUnit4SpringContextTests {

	private static final Logger m_logger = Logger
			.getLogger(AbstractDaoTest.class);
	@Autowired
	protected SessionFactory m_sessionFactory;
	@Autowired
	protected TransactionTemplate m_transactionTemplate;
	@Autowired
	protected DataSource m_dataSource;

	public void deleteAllData() throws SQLException {
		modifyAllTables("delete from ");
	}

	public void truncateAllTables() throws SQLException {
		modifyAllTables("truncate table ");
	}

	protected Connection getConnection() throws SQLException {
		return m_dataSource.getConnection();
	}

	private List<String> findTableNames(Statement stat) throws SQLException {

		List<String> result = new ArrayList<String>();
		ResultSet resultSet = stat.executeQuery("show tables;");
		try {
			while (resultSet.next()) {
				result.add(resultSet.getString(1));
			}
		} finally {
			resultSet.close();
		}
		// result.remove("HistoricalAlarm");
		m_logger.info("Tables : " + result);
		return result;
	}

	private void modifyAllTables(final String command) throws SQLException {
		long start = System.currentTimeMillis();
		Connection connection = getConnection();
		Statement stat = connection.createStatement();
		stat.execute("SET FOREIGN_KEY_CHECKS=0;");
		stat.execute("SET UNIQUE_CHECKS=0;");
		// stat.execute("SET AUTOCOMMIT=0;");
		for (String tableName : findTableNames(stat)) {
			String cmd = command + tableName + ";";
			m_logger.debug("Executing: " + cmd);
			stat.execute(cmd);
			// stat.execute("ALTER TABLE " + tableName + " AUTO_INCREMENT=1");
		}
		// stat.execute("SET AUTOCOMMIT=1;");
		stat.execute("SET FOREIGN_KEY_CHECKS=1;");
		stat.execute("SET UNIQUE_CHECKS=1;");
		// connection.close();

		m_logger.info("Drop time : " + (System.currentTimeMillis() - start));
	}

	@After
	public void destroy() throws SQLException {
		truncateAllTables();
	}
	@Test
	public void testContext(){
		Assert.assertNotNull(m_dataSource);
	}
}

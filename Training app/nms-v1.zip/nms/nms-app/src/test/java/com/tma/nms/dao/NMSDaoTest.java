package com.tma.nms.dao;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;

import com.tma.nms.api.Constanst;
import com.tma.nms.management.NMSObject;
import com.tma.nms.management.Status;
import com.tma.nms.management.dao.GenericDao;
import com.tma.nms.management.dao.GenericHibernateDao;
import com.tma.nms.management.metadata.Attribute;
import com.tma.nms.management.metadata.AttributeGroup;

public class NMSDaoTest extends AbstractDaoTest{

	@Autowired
	private NMSObjectDao m_nmsObjectDao;
	
	private GenericDao<AttributeGroup, Long> m_groupDao;
	
	private GenericDao<Attribute, Long> m_attributeDao;
	
	
	public NMSDaoTest(){
		
	}
	@Test
	public void testGetChildren(){
		m_transactionTemplate.execute(new TransactionCallback<Object>() {

			@Override
			public Object doInTransaction(TransactionStatus arg0) {
				List<NMSObject> objects = m_nmsObjectDao.findByObjectType(Constanst.SWITCH);
				Assert.assertEquals(1, objects.size());
				List<NMSObject> children = m_nmsObjectDao.getChildren(objects.get(0).getId());
				Assert.assertEquals(2, children.size());
				return null;
			}
		});
	}
	@Test
	public void testFindByObjectType(){
		m_transactionTemplate.execute(new TransactionCallback<Object>() {

			@Override
			public Object doInTransaction(TransactionStatus arg0) {
				List<NMSObject> objects = m_nmsObjectDao.findByObjectType(Constanst.SWITCH);
				Assert.assertEquals(1, objects.size());
				return null;
			}
		});
	}
	@Test
	public void testGetRootDevices(){
		m_transactionTemplate.execute(new TransactionCallback<Object>() {

			@Override
			public Object doInTransaction(TransactionStatus arg0) {
				List<NMSObject> objects = m_nmsObjectDao.getRootDevices();
				Assert.assertEquals(1, objects.size());
				return null;
			}
		});
	}
	@Test
	public void testMakePersistense(){
		m_transactionTemplate.execute(new TransactionCallback<Object>() {

			@Override
			public Object doInTransaction(TransactionStatus arg0) {
				List<NMSObject> objects = m_nmsObjectDao.findAll();
				Assert.assertEquals(3, objects.size());
				return null;
			}
		});
	}
	
	@Before
	public void init(){
		m_groupDao = new GenericHibernateDao<AttributeGroup, Long>(m_sessionFactory){};
		m_attributeDao = new GenericHibernateDao<Attribute, Long>(m_sessionFactory){};
    	m_transactionTemplate.execute(new TransactionCallback<Object>() {

			@Override
			public Object doInTransaction(TransactionStatus arg0) {
				NMSObject record = new NMSObject();
		    	record.setName("switch 1");
		    	record.setObjectType(Constanst.SWITCH);
		    	record.setParent(null);
		    	record.setStatus(com.tma.nms.management.Status.ACTIVE);
		    	
		    	List<AttributeGroup> groups = new ArrayList<AttributeGroup>();
		    	
		    	List<Attribute> metadata = new ArrayList<Attribute>();
		    	
		    	Attribute nameMeta = new Attribute();
		    	nameMeta.setDataType(String.class);
		    	nameMeta.setName("Name");
		    	nameMeta.setValue("switch 1");
		    	nameMeta.setReadable(true);
		    	nameMeta.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(nameMeta);
		    	
		    	metadata.add(nameMeta);
		    	
		    	Attribute statusMeta = new Attribute();
		    	statusMeta.setDataType(String.class);
		    	statusMeta.setName("Status");
		    	statusMeta.setValue(Status.ACTIVE.toString());
		    	statusMeta.setReadable(true);
		    	statusMeta.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(statusMeta);
		    	
		    	metadata.add(statusMeta);
		    	
		    	Attribute ipMeta = new Attribute();
		    	ipMeta.setDataType(String.class);
		    	ipMeta.setName("IP Address");
		    	ipMeta.setValue("127.0.0.1");
		    	ipMeta.setReadable(true);
		    	ipMeta.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(ipMeta);
		    	
		    	metadata.add(ipMeta);
		    	
		    	AttributeGroup metadatas = new AttributeGroup();
		    	metadatas.setAttributes(metadata);
		    	metadatas.setName("Generic Config");
		    	m_groupDao.makePersistence(metadatas);
		    	groups.add(metadatas);
		    	
		    	
		    	List<Attribute> specificConfig = new ArrayList<Attribute>();
		    	
		    	Attribute specMetaReadonly = new Attribute();
		    	specMetaReadonly.setDataType(String.class);
		    	specMetaReadonly.setName("Read Only Example");
		    	specMetaReadonly.setValue("readOnlyValue");
		    	specMetaReadonly.setReadable(true);
		    	specMetaReadonly.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(specMetaReadonly);
		    	
		    	specificConfig.add(specMetaReadonly);
		    	
		    	Attribute writeAbleMeta = new Attribute();
		    	writeAbleMeta.setDataType(String.class);
		    	writeAbleMeta.setName("Writable Example");
		    	writeAbleMeta.setReadable(true);
		    	writeAbleMeta.setWritable(true);
		    	
		    	m_attributeDao.makePersistence(writeAbleMeta);
		    	
		    	specificConfig.add(writeAbleMeta);
		    	
		    	AttributeGroup specMetas = new AttributeGroup();
		    	specMetas.setAttributes(specificConfig);
		    	specMetas.setName("Specific Config");
		    	m_groupDao.makePersistence(specMetas);
		    	groups.add(specMetas);
		    	
		    	
		    	record.setGroups(groups);
		    	
		    	m_nmsObjectDao.makePersistence(record);
				return null;
			}
    		
		});
    	
    	m_transactionTemplate.execute(new TransactionCallback<Object>() {

			@Override
			public Object doInTransaction(TransactionStatus arg0) {
				NMSObject parent = m_nmsObjectDao.getRootDevices().get(0);
				NMSObject record = new NMSObject();
		    	record.setName("Port 1");
		    	record.setObjectType(Constanst.PORT);
		    	record.setParent(parent);
		    	record.setStatus(com.tma.nms.management.Status.ACTIVE);
		    	
		    	List<AttributeGroup> groups = new ArrayList<AttributeGroup>();
		    	
		    	List<Attribute> metadata = new ArrayList<Attribute>();
		    	
		    	Attribute nameMeta = new Attribute();
		    	nameMeta.setDataType(String.class);
		    	nameMeta.setName("Name");
		    	nameMeta.setValue("Port 1");
		    	nameMeta.setReadable(true);
		    	nameMeta.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(nameMeta);
		    	
		    	metadata.add(nameMeta);
		    	
		    	Attribute statusMeta = new Attribute();
		    	statusMeta.setDataType(String.class);
		    	statusMeta.setName("Status");
		    	statusMeta.setValue(com.tma.nms.management.Status.ACTIVE.toString());
		    	statusMeta.setReadable(true);
		    	statusMeta.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(statusMeta);
		    	
		    	metadata.add(statusMeta);
		    	
		    	Attribute ipMeta = new Attribute();
		    	ipMeta.setDataType(String.class);
		    	ipMeta.setName("IP Address");
		    	ipMeta.setValue("127.0.0.2");
		    	ipMeta.setReadable(true);
		    	ipMeta.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(ipMeta);
		    	
		    	metadata.add(ipMeta);
		    	
		    	AttributeGroup metadatas = new AttributeGroup();
		    	metadatas.setAttributes(metadata);
		    	metadatas.setName("Generic Config");
		    	m_groupDao.makePersistence(metadatas);
		    	groups.add(metadatas);
		    	
		    	
		    	List<Attribute> specificConfig = new ArrayList<Attribute>();
		    	
		    	Attribute specMetaReadonly = new Attribute();
		    	specMetaReadonly.setDataType(String.class);
		    	specMetaReadonly.setName("Read Only Example");
		    	specMetaReadonly.setValue("readOnlyValue");
		    	specMetaReadonly.setReadable(true);
		    	specMetaReadonly.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(specMetaReadonly);
		    	
		    	specificConfig.add(specMetaReadonly);
		    	
		    	Attribute writeAbleMeta = new Attribute();
		    	writeAbleMeta.setDataType(String.class);
		    	writeAbleMeta.setName("Writable Example");
		    	writeAbleMeta.setReadable(true);
		    	writeAbleMeta.setWritable(true);
		    	
		    	m_attributeDao.makePersistence(writeAbleMeta);
		    	
		    	specificConfig.add(writeAbleMeta);
		    	
		    	AttributeGroup specMetas = new AttributeGroup();
		    	specMetas.setAttributes(specificConfig);
		    	specMetas.setName("Specific Config");
		    	m_groupDao.makePersistence(specMetas);
		    	groups.add(specMetas);
		    	
		    	
		    	record.setGroups(groups);
		    	
		    	m_nmsObjectDao.makePersistence(record);
				return null;
			}
    		
		});
    	
    	m_transactionTemplate.execute(new TransactionCallback<Object>() {

			@Override
			public Object doInTransaction(TransactionStatus arg0) {
				NMSObject parent = m_nmsObjectDao.getRootDevices().get(0);
				NMSObject record = new NMSObject();
		    	record.setName("Port 2");
		    	record.setObjectType(Constanst.PORT);
		    	record.setParent(parent);
		    	record.setStatus(com.tma.nms.management.Status.OFFLINE);
		    	
		    	List<AttributeGroup> groups = new ArrayList<AttributeGroup>();
		    	
		    	List<Attribute> metadata = new ArrayList<Attribute>();
		    	
		    	Attribute nameMeta = new Attribute();
		    	nameMeta.setDataType(String.class);
		    	nameMeta.setName("Name");
		    	nameMeta.setValue("Port 2");
		    	nameMeta.setReadable(true);
		    	nameMeta.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(nameMeta);
		    	
		    	metadata.add(nameMeta);
		    	
		    	Attribute statusMeta = new Attribute();
		    	statusMeta.setDataType(String.class);
		    	statusMeta.setName("Status");
		    	statusMeta.setValue(com.tma.nms.management.Status.OFFLINE.toString());
		    	statusMeta.setReadable(true);
		    	statusMeta.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(statusMeta);
		    	
		    	metadata.add(statusMeta);
		    	
		    	Attribute ipMeta = new Attribute();
		    	ipMeta.setDataType(String.class);
		    	ipMeta.setName("IP Address");
		    	ipMeta.setValue("127.0.0.3");
		    	ipMeta.setReadable(true);
		    	ipMeta.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(ipMeta);
		    	
		    	metadata.add(ipMeta);
		    	
		    	AttributeGroup metadatas = new AttributeGroup();
		    	metadatas.setAttributes(metadata);
		    	metadatas.setName("Generic Config");
		    	m_groupDao.makePersistence(metadatas);
		    	groups.add(metadatas);
		    	
		    	
		    	List<Attribute> specificConfig = new ArrayList<Attribute>();
		    	
		    	Attribute specMetaReadonly = new Attribute();
		    	specMetaReadonly.setDataType(String.class);
		    	specMetaReadonly.setName("Read Only Example");
		    	specMetaReadonly.setValue("readOnlyValue");
		    	specMetaReadonly.setReadable(true);
		    	specMetaReadonly.setWritable(false);
		    	
		    	m_attributeDao.makePersistence(specMetaReadonly);
		    	
		    	specificConfig.add(specMetaReadonly);
		    	
		    	Attribute writeAbleMeta = new Attribute();
		    	writeAbleMeta.setDataType(String.class);
		    	writeAbleMeta.setName("Writable Example");
		    	writeAbleMeta.setReadable(true);
		    	writeAbleMeta.setWritable(true);
		    	
		    	m_attributeDao.makePersistence(writeAbleMeta);
		    	
		    	specificConfig.add(writeAbleMeta);
		    	
		    	AttributeGroup specMetas = new AttributeGroup();
		    	specMetas.setAttributes(specificConfig);
		    	specMetas.setName("Specific Config");
		    	m_groupDao.makePersistence(specMetas);
		    	groups.add(specMetas);
		    	
		    	
		    	record.setGroups(groups);
		    	
		    	m_nmsObjectDao.makePersistence(record);
				return null;
			}
    		
		});
    	
    }
}

package com.tma.nms.management;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.tma.nms.management.metadata.AttributeGroup;

@Entity
public class NMSObject implements Serializable {
    private static final long serialVersionUID = 1L;
    public static final String PATH_CHAR = "/";
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, length = 100)
    private String objectType;

    @Column(name = "status", nullable = false)
    @Enumerated(EnumType.STRING)
    private Status m_status = Status.ACTIVE;

    @Column
    private String pathId;
    
    @ManyToOne
    private NMSObject parent;;

    @OneToMany(fetch = FetchType.LAZY)
    private List<AttributeGroup> groups;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public Status getStatus() {
        return m_status;
    }

    public void setStatus(Status status) {
        this.m_status = status;
    }
    /**
     * @return the pathId
     */
    public String getPathId() {
        if(parent != null) {
            pathId = parent.getPathId() + PATH_CHAR + getId();
        } else {
            pathId = PATH_CHAR + String.valueOf(getId());
        }
        return pathId;
    }

    /**
     * @param pathId the pathId to set
     */
    public void setPathId(String pathId) {
        this.pathId = pathId;
    }

    public NMSObject getParent() {
        return parent;
    }

    public void setParent(NMSObject parent) {
        this.parent = parent;
    }

	public List<AttributeGroup> getGroups() {
		return groups;
	}

	public void setGroups(List<AttributeGroup> groups) {
		this.groups = groups;
	}

}

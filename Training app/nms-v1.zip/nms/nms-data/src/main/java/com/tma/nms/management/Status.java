package com.tma.nms.management;

public enum Status {
    ACTIVE,
    OFFLINE
}

package com.tma.nms.management.alarm;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.tma.nms.management.NMSObject;

@Entity
public class Alarm implements Serializable{
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    @OneToOne(fetch=FetchType.EAGER)
    private NMSObject srcAlarm;
    
    @Enumerated(EnumType.ORDINAL) 
    private AlarmSeverity severity;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public NMSObject getSrcAlarm() {
		return srcAlarm;
	}

	public void setSrcAlarm(NMSObject srcAlarm) {
		this.srcAlarm = srcAlarm;
	}

	public AlarmSeverity getSeverity() {
		return severity;
	}

	public void setSeverity(AlarmSeverity severity) {
		this.severity = severity;
	}

    

}

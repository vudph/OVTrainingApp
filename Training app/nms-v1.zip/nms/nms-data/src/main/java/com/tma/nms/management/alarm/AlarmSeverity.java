package com.tma.nms.management.alarm;

public enum AlarmSeverity {
    Critical,
    Major,
    Minor;
}

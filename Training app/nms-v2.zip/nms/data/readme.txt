1) install mongodb
2) Add path of mongodb\bin to enviroment variable PATH
3) create databse "nms" & "nmstest"
4) Run import.bat
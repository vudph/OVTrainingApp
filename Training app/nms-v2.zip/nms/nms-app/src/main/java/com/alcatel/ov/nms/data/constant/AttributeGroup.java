package com.alcatel.ov.nms.data.constant;

public enum AttributeGroup {
    GENERAL,
    SPECIAL
}

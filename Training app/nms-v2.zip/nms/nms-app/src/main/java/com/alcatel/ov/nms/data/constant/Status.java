package com.alcatel.ov.nms.data.constant;

public enum Status {
    ACTIVE,
    OFFLINE
}

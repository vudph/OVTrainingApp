package com.alcatel.ov.nms.data.constant;

public enum TypeObject {
    SWITCH,
    ROUTER,
    PORT
}
